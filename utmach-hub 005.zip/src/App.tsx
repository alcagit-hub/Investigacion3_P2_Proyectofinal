import React, { useEffect, useState } from 'react';
import { ActiveModule, CampusSpace, IncidentReport, ToastNotification, UserAccount, UserSessionStats, VibeMessage } from './types';
import { DEFAULT_TEACHERS, INITIAL_SPACES } from './data/mockData';

import { Sidebar } from './components/Sidebar';
import { MainPanel } from './components/MainPanel';
import { SpaceManagement } from './components/SpaceManagement';
import { HubDestinos } from './components/HubDestinos';
import { VibeUtmach } from './components/VibeUtmach';
import { QrExporterModal } from './components/QrExporterModal';
import { AuthModal } from './components/AuthModal';
import { ExitScreen } from './components/ExitScreen';
import { MasterTimerBanner } from './components/MasterTimerBanner';
import { Bell, CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const App: React.FC = () => {
  // Navigation & View Module State
  const [activeModule, setActiveModule] = useState<ActiveModule>('panel_principal');

  // App Lock / Exit State
  const [isAppExited, setIsAppExited] = useState<boolean>(false);

  // User Accounts State (Default Teachers + LocalStorage persisted teachers)
  const [teachers, setTeachers] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem('utmach_teachers');
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : DEFAULT_TEACHERS;
      }
    } catch (err) {
      console.error('Error loading teachers from localStorage:', err);
    }
    return DEFAULT_TEACHERS;
  });

  // Auth State (Default is Guest user)
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    return {
      id: 'guest-user',
      email: 'invitado@utmachala.edu.ec',
      name: 'Usuario Invitado',
      role: 'guest',
    };
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Spaces Data State
  const [spaces, setSpaces] = useState<CampusSpace[]>(INITIAL_SPACES);

  // Incident Reports State
  const [incidents, setIncidents] = useState<IncidentReport[]>([]);

  // Vibe UTMACH Public Feed Messages State
  const [vibeMessages, setVibeMessages] = useState<VibeMessage[]>([
    {
      id: 'msg-init-1',
      author: 'Ing. Carlos Mendoza',
      authorRole: 'teacher',
      content: '¡Bienvenidos a la plataforma UTMACH HUB del Campus Central!',
      timestamp: '10:00 AM',
    }
  ]);

  // Toast Notifications State
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // User Statistics History State (accumulates visited places & km walked)
  const [sessionStats, setSessionStats] = useState<UserSessionStats>({
    totalMeters: 0,
    visitedPlaces: {},
  });

  // Handler to record route distance and visited destination
  const handleRecordRoute = (meters: number, destinationSpaceId: string) => {
    setSessionStats((prev) => ({
      totalMeters: prev.totalMeters + meters,
      visitedPlaces: {
        ...prev.visitedPlaces,
        [destinationSpaceId]: (prev.visitedPlaces[destinationSpaceId] || 0) + 1,
      },
    }));
  };

  // ==========================================================
  // TEMPORIZADOR GLOBAL ÚNICO MAESTRO (60 SEGUNDOS)
  // ==========================================================
  const [secondsLeft, setSecondsLeft] = useState<number>(60);

  useEffect(() => {
    if (isAppExited) return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          // --- MASTER CLEANUP AT 0 SECONDS ---
          // 1. Reset all classroom occupations
          setSpaces((prevSpaces) =>
            prevSpaces.map((s) =>
              s.type === 'aula'
                ? { ...s, isOccupied: false, occupiedBy: null, occupiedByName: null, occupiedAt: null }
                : s
            )
          );

          // 2. Clear Vibe UTMACH public messages
          setVibeMessages([]);

          // 3. Clear all active incident reports
          setIncidents([]);

          // 4. Clear/Reset user session statistics history
          setSessionStats({
            totalMeters: 0,
            visitedPlaces: {},
          });

          // 5. Trigger Toast notification
          showToast(
            '⏳ Temporizador Maestro (60s): Se ha ejecutado el restablecimiento global de aulas, mensajes Vibe, incidentes y estadísticas de recorrido.',
            'info'
          );

          return 60; // Reset countdown cycle back to 60s
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isAppExited]);

  // Helper for displaying Toast notifications
  const showToast = (message: string, type: ToastNotification['type'] = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, message }]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  // Handler for Updating Classroom Occupation
  const handleUpdateSpaceOccupation = (
    spaceId: string,
    isOccupied: boolean,
    teacherEmail: string | null
  ) => {
    setSpaces((prev) =>
      prev.map((s) => {
        if (s.id === spaceId) {
          return {
            ...s,
            isOccupied,
            occupiedBy: teacherEmail,
            occupiedAt: isOccupied ? new Date().toLocaleTimeString() : null,
          };
        }
        return s;
      })
    );
  };

  // Handler for Adding New Incident Report
  const handleAddIncident = (
    locationId: string,
    locationName: string,
    description: string,
    authorEmail: string
  ) => {
    const newInc: IncidentReport = {
      id: `inc-${Date.now()}`,
      locationId,
      locationName,
      description,
      reportedBy: authorEmail,
      reportedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      confirms: 1,
      denials: 0,
      votedUsers: [authorEmail],
    };
    setIncidents((prev) => [...prev.filter((i) => i.locationId !== locationId), newInc]);
  };

  // Handler for Voting/Confirming/Denying Incident Report
  const handleVoteIncident = (
    incidentId: string,
    isConfirming: boolean,
    userEmail: string
  ) => {
    setIncidents((prev) =>
      prev
        .map((inc) => {
          if (inc.id === incidentId) {
            const hasVoted = inc.votedUsers.includes(userEmail);
            if (hasVoted) return inc;

            const newConfirms = isConfirming ? inc.confirms + 1 : inc.confirms;
            const newDenials = !isConfirming ? inc.denials + 1 : inc.denials;

            return {
              ...inc,
              confirms: newConfirms,
              denials: newDenials,
              votedUsers: [...inc.votedUsers, userEmail],
            };
          }
          return inc;
        })
        .filter((inc) => inc.denials <= inc.confirms) // Remove incident if denials exceed confirmations
    );
  };

  // Handler for Publishing Vibe Message
  const handleSendMessage = (content: string) => {
    if (!currentUser) return;
    const newMsg: VibeMessage = {
      id: `msg-${Date.now()}`,
      author: currentUser.name,
      authorRole: currentUser.role,
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setVibeMessages((prev) => [newMsg, ...prev]);
    showToast(`🔔 Vibe UTMACH: ${currentUser.name} publicó un nuevo aviso público.`, 'success');
  };

  // Teacher Registration Save Handler
  const handleCreateTeacherAccount = (newTeacher: UserAccount, password: string) => {
    const updated = [...teachers, newTeacher];
    setTeachers(updated);
    try {
      localStorage.setItem('utmach_teachers', JSON.stringify(updated));
    } catch (err) {
      console.error('Error saving teacher to localStorage:', err);
    }
    showToast(`¡Cuenta docente "${newTeacher.name}" creada e identificada en el sistema!`, 'success');
  };

  if (isAppExited) {
    return (
      <ExitScreen
        onRestart={() => {
          setIsAppExited(false);
          setSecondsLeft(60);
          showToast('Aplicación UTMACH HUB reiniciada.', 'info');
        }}
      />
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100 selection:bg-sky-500 selection:text-white">
      {/* Fixed Left Vertical Sidebar */}
      <Sidebar
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        currentUser={currentUser}
        secondsLeft={secondsLeft}
        onLogout={() => {
          setCurrentUser({
            id: 'guest-user',
            email: 'invitado@utmachala.edu.ec',
            name: 'Usuario Invitado',
            role: 'guest',
          });
          if (activeModule === 'qr_export') {
            setActiveModule('panel_principal');
          }
          setIsAuthModalOpen(true);
          showToast('Sesión de usuario cerrada. Cambiado a perfil Invitado.', 'info');
        }}
        onExitApp={() => setIsAppExited(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Right Content Workspace */}
      <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto space-y-6 overflow-y-auto">
        {/* Global Master Timer Top Indicator */}
        <MasterTimerBanner
          secondsLeft={secondsLeft}
          onForceReset={() => {
            setSecondsLeft(60);
            showToast('Ciclo de 60s reiniciado manualmente.', 'info');
          }}
        />

        {/* Dynamic Module Renderer */}
        {activeModule === 'panel_principal' && (
          <MainPanel spaces={spaces} sessionStats={sessionStats} currentUser={currentUser} />
        )}

        {activeModule === 'gestion_espacios' && (
          <SpaceManagement
            spaces={spaces}
            currentUser={currentUser}
            onUpdateSpaceOccupation={handleUpdateSpaceOccupation}
            onShowToast={showToast}
          />
        )}

        {activeModule === 'hub_destinos' && (
          <HubDestinos
            spaces={spaces}
            currentUser={currentUser}
            incidents={incidents}
            onAddIncident={handleAddIncident}
            onVoteIncident={handleVoteIncident}
            onShowToast={showToast}
            onRecordRoute={handleRecordRoute}
            sessionStats={sessionStats}
          />
        )}

        {activeModule === 'vibe_utmach' && (
          <VibeUtmach
            messages={vibeMessages}
            currentUser={currentUser}
            onSendMessage={handleSendMessage}
            secondsLeft={secondsLeft}
          />
        )}

        {activeModule === 'qr_export' && (
          currentUser?.role === 'teacher' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-slate-900 p-4 rounded-2xl border border-slate-800">
                <h2 className="font-extrabold text-lg text-white">
                  Módulo de Exportación de Códigos QR de Aulas
                </h2>
                <button
                  onClick={() => setActiveModule('gestion_espacios')}
                  className="text-xs text-sky-400 font-bold hover:underline"
                >
                  Volver a Gestión de Espacios
                </button>
              </div>
              <QrExporterModal
                spaces={spaces}
                isOpen={true}
                onClose={() => setActiveModule('panel_principal')}
              />
            </div>
          ) : (
            <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center space-y-4">
              <h3 className="text-lg font-bold text-slate-100">Acceso Restringido</h3>
              <p className="text-xs text-slate-400">
                Los usuarios en modo Invitado únicamente pueden visualizar el estado de las aulas. La generación y exportación de códigos QR está reservada para Docentes.
              </p>
              <button
                onClick={() => setActiveModule('panel_principal')}
                className="px-4 py-2 bg-sky-600 text-white font-bold text-xs rounded-xl hover:bg-sky-500 transition-colors"
              >
                Ir al Panel Principal
              </button>
            </div>
          )
        )}
      </main>

      {/* Authentication & Profile Switching Modal */}
      <AuthModal
        teachers={teachers}
        isOpen={isAuthModalOpen}
        onLoginTeacher={(account) => {
          setCurrentUser(account);
          setIsAuthModalOpen(false);
          showToast(`¡Bienvenido/a, ${account.name}! Sesión iniciada como Docente.`, 'success');
        }}
        onLoginGuest={() => {
          setCurrentUser({
            id: 'guest-user',
            email: 'invitado@utmachala.edu.ec',
            name: 'Usuario Invitado',
            role: 'guest',
          });
          setIsAuthModalOpen(false);
          showToast('Navegando en modo Invitado.', 'info');
        }}
        onCreateTeacherAccount={handleCreateTeacherAccount}
        onExitApp={() => setIsAppExited(true)}
      />

      {/* Toast Notifications Overlay */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-xl border shadow-2xl text-xs flex items-center justify-between gap-3 animate-in slide-in-from-bottom-5 duration-200 ${
              toast.type === 'success'
                ? 'bg-emerald-950/95 border-emerald-500/80 text-emerald-100'
                : toast.type === 'error'
                ? 'bg-rose-950/95 border-rose-500/80 text-rose-100'
                : toast.type === 'warning'
                ? 'bg-amber-950/95 border-amber-500/80 text-amber-100'
                : 'bg-sky-950/95 border-sky-500/80 text-sky-100'
            }`}
          >
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 shrink-0 opacity-80" />
              <span className="font-medium leading-snug">{toast.message}</span>
            </div>
            <button
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="p-1 rounded hover:bg-black/20 text-white/80 shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
