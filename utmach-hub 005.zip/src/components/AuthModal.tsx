import React, { useState } from 'react';
import { UserAccount } from '../types';
import { INSTITUTIONAL_PASSWORD } from '../data/mockData';
import { UtmachLogo } from './UtmachLogo';
import { ShieldCheck, User, Lock, Mail, KeyRound, ArrowRight, UserPlus, LogIn, Power, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AuthModalProps {
  teachers: UserAccount[];
  isOpen: boolean;
  onLoginTeacher: (teacherAccount: UserAccount) => void;
  onLoginGuest: () => void;
  onCreateTeacherAccount: (newTeacher: UserAccount, password: string) => void;
  onExitApp: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  teachers,
  isOpen,
  onLoginTeacher,
  onLoginGuest,
  onCreateTeacherAccount,
  onExitApp,
}) => {
  const [activeTab, setActiveTab] = useState<'guest' | 'login' | 'register'>('guest');

  // Teacher Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Teacher Registration Form State (Requires Institutional Verification)
  const [instPassword, setInstPassword] = useState('');
  const [isInstVerified, setIsInstVerified] = useState(false);
  const [instError, setInstError] = useState<string | null>(null);

  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPersonalPassword, setRegPersonalPassword] = useState('');
  const [regError, setRegError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Teacher Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const match = teachers.find(
      (t) => t.email.toLowerCase() === loginEmail.trim().toLowerCase()
    );

    if (match) {
      onLoginTeacher(match);
    } else {
      setLoginError('Correo docente no registrado o contraseña no válida. Verifique sus credenciales.');
    }
  };

  // Step 1: Verify Institutional Password
  const handleVerifyInstitutional = (e: React.FormEvent) => {
    e.preventDefault();
    setInstError(null);

    if (instPassword.trim() === INSTITUTIONAL_PASSWORD) {
      setIsInstVerified(true);
    } else {
      setInstError('Contraseña Institucional incorrecta. Debe ingresar la clave oficial entregada por UTMACH.');
    }
  };

  // Step 2: Register New Teacher Account
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (!regEmail.includes('@')) {
      setRegError('Ingrese un correo electrónico institucional válido.');
      return;
    }

    if (teachers.some((t) => t.email.toLowerCase() === regEmail.trim().toLowerCase())) {
      setRegError('El correo ingresado ya pertenece a una cuenta docente existente.');
      return;
    }

    const newTeacher: UserAccount = {
      id: `doc-user-${Date.now()}`,
      email: regEmail.trim().toLowerCase(),
      name: regName.trim() || 'Docente UTMACH',
      role: 'teacher',
      isDefault: false,
    };

    onCreateTeacherAccount(newTeacher, regPersonalPassword);
    onLoginTeacher(newTeacher);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl relative flex flex-col">
        {/* Header Branding */}
        <div className="p-6 bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 border-b border-slate-800 text-center flex flex-col items-center gap-3">
          <UtmachLogo className="w-12 h-12" showText={false} />
          <div>
            <h2 className="text-xl font-extrabold text-white tracking-tight">
              UTMACH HUB - Acceso al Sistema
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Universidad Técnica de Machala • Plataforma Web Integrada
            </p>
          </div>
        </div>

        {/* Tab Selector Navigation */}
        <div className="grid grid-cols-3 bg-slate-950 border-b border-slate-800 p-1.5 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('guest')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'guest' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Invitado
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('login')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'login' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            Docente
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('register')}
            className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'register' ? 'bg-sky-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            Crear Cuenta
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 space-y-4">
          {/* TAB 1: INVITADO */}
          {activeTab === 'guest' && (
            <div className="space-y-4 text-center">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <span className="bg-sky-950 text-sky-300 text-[10px] font-bold px-2 py-0.5 rounded border border-sky-800 uppercase">
                  Acceso Modo Invitado
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Podrá navegar libremente por el Panel Principal, consultar el mapa 2D del campus, buscar rutas en Hub Destinos y participar en el feed Vibe UTMACH con permisos de solo lectura.
                </p>
              </div>

              <button
                type="button"
                onClick={onLoginGuest}
                className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-sky-950/50"
              >
                <span>Entrar como Invitado</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* TAB 2: LOGIN DOCENTE */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-3">
              {loginError && (
                <div className="p-3 bg-rose-950/80 border border-rose-500/60 rounded-xl text-xs text-rose-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Correo Electrónico Docente:
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="ejemplo@utmachala.edu.ec"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Contraseña Personal:
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg mt-4"
              >
                <span>Iniciar Sesión Docente</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* TAB 3: CREAR CUENTA DOCENTE (PASO 1: VERIFICACIÓN INSTITUCIONAL, PASO 2: DATOS) */}
          {activeTab === 'register' && (
            <div>
              {!isInstVerified ? (
                /* STEP 1: INSTITUTIONAL PASSWORD VERIFICATION */
                <form onSubmit={handleVerifyInstitutional} className="space-y-3">
                  <div className="p-3 bg-blue-950/50 border border-blue-800/60 rounded-xl text-xs text-sky-200">
                    <p className="font-bold text-sky-100">Paso 1: Verificación de Identidad Institucional</p>
                    <p className="text-[11px] text-sky-300/90 mt-0.5">
                      Para registrar una nueva cuenta docente, debe verificar la <strong>Contraseña Institucional</strong> oficial.
                    </p>
                  </div>

                  {instError && (
                    <div className="p-2.5 bg-rose-950/80 border border-rose-500/60 rounded-xl text-xs text-rose-200 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{instError}</span>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-300">
                        Contraseña Institucional UTMACH:
                      </label>
                    </div>

                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        value={instPassword}
                        onChange={(e) => setInstPassword(e.target.value)}
                        placeholder="Ingrese la clave institucional proveída por la administración"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
                        required
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg"
                  >
                    <span>Verificar Contraseña Institucional</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                /* STEP 2: REGISTRATION FORM */
                <form onSubmit={handleRegisterSubmit} className="space-y-3">
                  <div className="p-2.5 bg-emerald-950/50 border border-emerald-800/60 rounded-xl text-xs text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Clave institucional verificada correctamente. Ingrese sus datos personales.</span>
                  </div>

                  {regError && (
                    <div className="p-2.5 bg-rose-950/80 border border-rose-500/60 rounded-xl text-xs text-rose-200 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{regError}</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Nombre Completo Docente:
                    </label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="Ej: Dra. Gabriela Torres"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Correo Institucional (@utmachala.edu.ec):
                    </label>
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="gtorres@utmachala.edu.ec"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Contraseña Personal:
                    </label>
                    <input
                      type="password"
                      value={regPersonalPassword}
                      onChange={(e) => setRegPersonalPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg"
                  >
                    <span>Guardar Cuenta y Entrar</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Footer: Exit Program Option */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">UTMACH HUB v2.5</span>
          <button
            type="button"
            onClick={onExitApp}
            className="text-xs text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Power className="w-4 h-4" />
            Cerrar Programa / Salir
          </button>
        </div>
      </div>
    </div>
  );
};
