import React, { useState } from 'react';
import { CampusSpace } from '../types';
import { Info, MapPin, Trees, Building2, Coffee, ShieldAlert, Sparkles } from 'lucide-react';

interface CampusMap2DProps {
  spaces: CampusSpace[];
  onSelectSpace?: (space: CampusSpace) => void;
}

export const CampusMap2D: React.FC<CampusMap2DProps> = ({ spaces, onSelectSpace }) => {
  const [hoveredSpace, setHoveredSpace] = useState<CampusSpace | null>(null);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 md:p-6 shadow-2xl relative overflow-hidden backdrop-blur-md">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-sky-400" />
              Mapa Estático 2D del Campus UTMACH
            </h3>
            <span className="text-[11px] bg-sky-950 text-sky-300 border border-sky-800/60 px-2 py-0.5 rounded-full font-medium">
              Vista Arquitectónica
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Ilustración arquitectónica del Campus Central con arcos de ingreso, infraestructuras y reservas ecológicas.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs bg-amber-500/10 border border-amber-500/30 text-amber-300 px-3 py-1.5 rounded-lg">
          <Info className="w-4 h-4 shrink-0 text-amber-400" />
          <span>Mapa puramente de visualización estática.</span>
        </div>
      </div>

      {/* Map Interactive Container */}
      <div className="relative w-full aspect-[16/9] min-h-[380px] bg-emerald-950/30 rounded-xl border border-slate-800/80 overflow-hidden shadow-inner flex items-center justify-center">
        {/* SVG Campus Background */}
        <svg viewBox="0 0 1000 600" className="w-full h-full object-cover">
          <defs>
            {/* Campus Grass Pattern */}
            <radialGradient id="grassGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#064e3b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#022c22" stopOpacity="0.9" />
            </radialGradient>

            {/* Building Gradient - Static Blue Architecture */}
            <linearGradient id="staticBuildingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e3a8a" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>

            {/* Road Pattern */}
            <linearGradient id="roadGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#334155" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>

            {/* Entrance Arch Pattern */}
            <linearGradient id="archGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="50%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>
          </defs>

          {/* Base Grass Canvas */}
          <rect width="1000" height="600" fill="url(#grassGrad)" />

          {/* Decorative Grid Lines / Pedestrian Walks */}
          <path d="M 500 60 V 540" stroke="#475569" strokeWidth="18" strokeDasharray="12 6" opacity="0.4" />
          <path d="M 150 300 H 850" stroke="#475569" strokeWidth="14" opacity="0.3" />
          <path d="M 250 150 Q 500 220 750 150" stroke="#0ea5e9" strokeWidth="4" fill="none" opacity="0.25" strokeDasharray="6 4" />

          {/* Central Plaza Oval */}
          <ellipse cx="500" cy="300" rx="140" ry="80" fill="#0f172a" stroke="#0ea5e9" strokeWidth="3" opacity="0.8" />
          <ellipse cx="500" cy="300" rx="90" ry="50" fill="#047857" stroke="#10b981" strokeWidth="2" opacity="0.9" />
          <text x="500" y="303" textAnchor="middle" fill="#a7f3d0" fontSize="11" fontWeight="bold" letterSpacing="1">
            PLAZA ESTUDIANTIL UTMACH
          </text>

          {/* =========================================
              ENTRADAS CON ARCOS CUADRÁTICOS 2D
             ========================================= */}
          {/* ENTRADA PRINCIPAL (SUR - ABAJO) */}
          <g transform="translate(420, 520)">
            {/* Road Access */}
            <rect x="30" y="20" width="100" height="60" fill="url(#roadGrad)" rx="4" />
            <line x1="80" y1="20" x2="80" y2="80" stroke="#fef08a" strokeWidth="2" strokeDasharray="6 4" />
            
            {/* 2D Quadratic Arch Structure */}
            <path d="M 10 70 Q 80 10 150 70" fill="none" stroke="url(#archGrad)" strokeWidth="10" strokeLinecap="round" />
            <path d="M 20 70 Q 80 20 140 70" fill="none" stroke="#e0f2fe" strokeWidth="3" strokeLinecap="round" />
            <rect x="5" y="65" width="18" height="15" fill="#0369a1" rx="2" />
            <rect x="137" y="65" width="18" height="15" fill="#0369a1" rx="2" />
            
            <text x="80" y="12" textAnchor="middle" fill="#38bdf8" fontSize="12" fontWeight="900" letterSpacing="0.5">
              ARCO ENTRADA PRINCIPAL
            </text>
          </g>

          {/* ENTRADA TRASERA (NORTE - ARRIBA) */}
          <g transform="translate(420, 10)">
            {/* Road Access */}
            <rect x="30" y="0" width="100" height="50" fill="url(#roadGrad)" rx="4" />
            <line x1="80" y1="0" x2="80" y2="50" stroke="#fef08a" strokeWidth="2" strokeDasharray="6 4" />

            {/* 2D Quadratic Arch Structure */}
            <path d="M 15 50 Q 80 5 145 50" fill="none" stroke="url(#archGrad)" strokeWidth="8" strokeLinecap="round" />
            <path d="M 25 50 Q 80 14 135 50" fill="none" stroke="#bae6fd" strokeWidth="2.5" strokeLinecap="round" />
            <rect x="10" y="45" width="15" height="12" fill="#0284c7" rx="2" />
            <rect x="135" y="45" width="15" height="12" fill="#0284c7" rx="2" />

            <text x="80" y="62" textAnchor="middle" fill="#38bdf8" fontSize="11" fontWeight="bold">
              ARCO ENTRADA TRASERA
            </text>
          </g>

          {/* =========================================
              ÁREAS VERDES / ÁRBOLES Y BOSQUES 2D
             ========================================= */}
          {/* BOSQUETILLO NORTE */}
          <g transform="translate(120, 70)">
            {/* Forest Cluster */}
            <path d="M 20 50 Q 50 10 80 50 Q 110 20 140 50 Q 170 30 190 70 Q 100 110 20 50 Z" fill="#065f46" opacity="0.9" stroke="#10b981" strokeWidth="1.5" />
            
            {/* 2D Trees */}
            <g transform="translate(40,40)">
              <rect x="12" y="25" width="6" height="15" fill="#78350f" />
              <circle cx="15" cy="18" r="16" fill="#10b981" />
              <circle cx="10" cy="12" r="12" fill="#34d399" opacity="0.8" />
            </g>

            <g transform="translate(90,30)">
              <rect x="12" y="25" width="6" height="15" fill="#78350f" />
              <circle cx="15" cy="18" r="18" fill="#059669" />
              <circle cx="20" cy="12" r="12" fill="#34d399" opacity="0.8" />
            </g>

            <g transform="translate(140,50)">
              <rect x="12" y="25" width="6" height="15" fill="#78350f" />
              <circle cx="15" cy="18" r="15" fill="#10b981" />
            </g>

            <text x="100" y="105" textAnchor="middle" fill="#6ee7b7" fontSize="11" fontWeight="bold">
              BOSQUETILLO AGROPECUARIO
            </text>
          </g>

          {/* JARDÍN CENTRAL */}
          <g transform="translate(680, 220)">
            <path d="M 10 30 Q 60 5 120 30 Q 160 80 120 130 Q 50 150 10 100 Z" fill="#065f46" opacity="0.85" stroke="#34d399" strokeWidth="1.5" />
            
            <g transform="translate(50,40)">
              <rect x="10" y="20" width="5" height="12" fill="#78350f" />
              <circle cx="12.5" cy="14" r="14" fill="#10b981" />
            </g>
            <g transform="translate(90,70)">
              <rect x="10" y="20" width="5" height="12" fill="#78350f" />
              <circle cx="12.5" cy="14" r="16" fill="#059669" />
            </g>

            <text x="75" y="125" textAnchor="middle" fill="#a7f3d0" fontSize="11" fontWeight="bold">
              JARDÍN CENTRAL UTMACH
            </text>
          </g>

          {/* =========================================
              EDIFICIOS Y AULAS (ESTRUCTURA ESTÁTICA)
             ========================================= */}
          {/* BLOQUE A - FACULTAD DE INGENIERÍA */}
          <g transform="translate(80, 190)">
            <rect x="0" y="0" width="220" height="120" fill="url(#staticBuildingGrad)" stroke="#3b82f6" strokeWidth="2.5" rx="8" />
            <rect x="10" y="10" width="200" height="30" fill="#1e293b" rx="4" />
            <text x="110" y="30" textAnchor="middle" fill="#93c5fd" fontSize="12" fontWeight="bold">
              BLOQUE A - FICI (INGENIERÍA)
            </text>
            
            {/* Windows 2D */}
            <g fill="#38bdf8" opacity="0.7">
              <rect x="20" y="55" width="25" height="20" rx="2" />
              <rect x="55" y="55" width="25" height="20" rx="2" />
              <rect x="90" y="55" width="25" height="20" rx="2" />
              <rect x="125" y="55" width="25" height="20" rx="2" />
              <rect x="160" y="55" width="25" height="20" rx="2" />

              <rect x="20" y="85" width="25" height="20" rx="2" />
              <rect x="55" y="85" width="25" height="20" rx="2" />
              <rect x="90" y="85" width="25" height="20" rx="2" />
              <rect x="125" y="85" width="25" height="20" rx="2" />
              <rect x="160" y="85" width="25" height="20" rx="2" />
            </g>
          </g>

          {/* BLOQUE B - CIENCIAS EMPRESARIALES */}
          <g transform="translate(680, 70)">
            <rect x="0" y="0" width="200" height="110" fill="url(#staticBuildingGrad)" stroke="#3b82f6" strokeWidth="2.5" rx="8" />
            <rect x="10" y="10" width="180" height="25" fill="#1e293b" rx="4" />
            <text x="100" y="27" textAnchor="middle" fill="#93c5fd" fontSize="11" fontWeight="bold">
              BLOQUE B - EMPRESARIALES
            </text>

            <g fill="#38bdf8" opacity="0.7">
              <rect x="20" y="45" width="22" height="18" rx="2" />
              <rect x="52" y="45" width="22" height="18" rx="2" />
              <rect x="84" y="45" width="22" height="18" rx="2" />
              <rect x="116" y="45" width="22" height="18" rx="2" />
              <rect x="148" y="45" width="22" height="18" rx="2" />

              <rect x="20" y="75" width="22" height="18" rx="2" />
              <rect x="52" y="75" width="22" height="18" rx="2" />
              <rect x="84" y="75" width="22" height="18" rx="2" />
              <rect x="116" y="75" width="22" height="18" rx="2" />
              <rect x="148" y="75" width="22" height="18" rx="2" />
            </g>
          </g>

          {/* BLOQUE C - SALUD Y QUÍMICAS */}
          <g transform="translate(720, 390)">
            <rect x="0" y="0" width="190" height="110" fill="url(#staticBuildingGrad)" stroke="#3b82f6" strokeWidth="2.5" rx="8" />
            <rect x="10" y="10" width="170" height="25" fill="#1e293b" rx="4" />
            <text x="95" y="27" textAnchor="middle" fill="#93c5fd" fontSize="11" fontWeight="bold">
              BLOQUE C - SALUD
            </text>

            <g fill="#38bdf8" opacity="0.7">
              <rect x="20" y="45" width="20" height="18" rx="2" />
              <rect x="50" y="45" width="20" height="18" rx="2" />
              <rect x="80" y="45" width="20" height="18" rx="2" />
              <rect x="110" y="45" width="20" height="18" rx="2" />
              <rect x="140" y="45" width="20" height="18" rx="2" />
            </g>
          </g>

          {/* BAR UNIVERSITARIO */}
          <g transform="translate(520, 390)">
            <rect x="0" y="0" width="140" height="85" fill="#831843" stroke="#f43f5e" strokeWidth="2" rx="6" />
            <rect x="8" y="8" width="124" height="22" fill="#500724" rx="3" />
            <text x="70" y="23" textAnchor="middle" fill="#fecdd3" fontSize="10" fontWeight="bold">
              BAR / CAFETERÍA
            </text>
            <circle cx="70" cy="55" r="14" fill="#fb7185" opacity="0.6" />
            <path d="M 64 55 H 76 M 70 49 V 61" stroke="#fff" strokeWidth="2" />
          </g>

          {/* SERVICIOS HIGIÉNICOS - BAÑOS BLOQUE A */}
          <g transform="translate(100, 340)">
            <rect x="0" y="0" width="110" height="60" fill="#1e1b4b" stroke="#818cf8" strokeWidth="2" rx="6" />
            <text x="55" y="35" textAnchor="middle" fill="#c7d2fe" fontSize="10" fontWeight="bold">
              BAÑOS BLOQUE A
            </text>
          </g>

          {/* SERVICIOS HIGIÉNICOS - BAÑOS BLOQUE B */}
          <g transform="translate(730, 200)">
            <rect x="0" y="0" width="110" height="55" fill="#1e1b4b" stroke="#818cf8" strokeWidth="2" rx="6" />
            <text x="55" y="32" textAnchor="middle" fill="#c7d2fe" fontSize="10" fontWeight="bold">
              BAÑOS BLOQUE B
            </text>
          </g>

          {/* =========================================
              PUNTOS DE UBICACIÓN INTERACTIVOS (MARKERS)
             ========================================= */}
          {spaces.map((space) => {
            const svgX = (space.x / 100) * 1000;
            const svgY = (space.y / 100) * 600;
            const isHovered = hoveredSpace?.id === space.id;

            return (
              <g
                key={space.id}
                transform={`translate(${svgX}, ${svgY})`}
                className="cursor-pointer transition-transform duration-200"
                onMouseEnter={() => setHoveredSpace(space)}
                onMouseLeave={() => setHoveredSpace(null)}
                onClick={() => onSelectSpace?.(space)}
              >
                {/* Marker Pulse Halo */}
                <circle
                  r={isHovered ? '20' : '14'}
                  fill="#0284c7"
                  opacity={isHovered ? '0.5' : '0.25'}
                  className="transition-all duration-300"
                />

                {/* Marker Circle */}
                <circle
                  r="10"
                  fill="#0369a1"
                  stroke="#38bdf8"
                  strokeWidth="2.5"
                  className="drop-shadow-md"
                />

                {/* Inner Icon Dot */}
                <circle r="4" fill="#ffffff" />

                {/* Label text on hover or zoom */}
                {isHovered && (
                  <g transform="translate(0, -22)">
                    <rect
                      x="-70"
                      y="-22"
                      width="140"
                      height="22"
                      fill="#0f172a"
                      stroke="#38bdf8"
                      strokeWidth="1"
                      rx="4"
                    />
                    <text
                      x="0"
                      y="-8"
                      textAnchor="middle"
                      fill="#e0f2fe"
                      fontSize="10"
                      fontWeight="bold"
                    >
                      {space.name}
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip Box */}
        {hoveredSpace && (
          <div className="absolute top-4 right-4 bg-slate-900/95 border border-sky-500/50 p-3 rounded-xl shadow-2xl max-w-xs backdrop-blur-md pointer-events-none animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
              <h4 className="font-bold text-xs text-sky-200">{hoveredSpace.name}</h4>
            </div>
            <p className="text-[11px] text-slate-300">{hoveredSpace.description}</p>
            <div className="mt-2 text-[10px] text-slate-400 font-mono flex items-center justify-between border-t border-slate-800 pt-1.5">
              <span>Ubicación: {hoveredSpace.block}</span>
              <span className="text-sky-400">Tipo: {hoveredSpace.type.replace('_', ' ')}</span>
            </div>
          </div>
        )}
      </div>

      {/* Map Legend */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-xs text-slate-300">
        <div className="flex items-center gap-2 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/50">
          <div className="w-3 h-3 rounded-full bg-sky-500 border border-sky-300" />
          <span>Arcos 2D de Entrada</span>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/50">
          <div className="w-3 h-3 rounded-full bg-emerald-500 border border-emerald-300" />
          <span>Áreas Verdes & Bosque</span>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/50">
          <div className="w-3 h-3 rounded-full bg-blue-700 border border-blue-400" />
          <span>Aulas y Edificios</span>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/40 px-2.5 py-1.5 rounded-lg border border-slate-700/50">
          <div className="w-3 h-3 rounded-full bg-rose-600 border border-rose-300" />
          <span>Bar & Servicios</span>
        </div>
      </div>
    </div>
  );
};
