import React from 'react';
import { UtmachLogo } from './UtmachLogo';
import { Power, RotateCcw, Heart, CheckCircle2 } from 'lucide-react';

interface ExitScreenProps {
  onRestart: () => void;
}

export const ExitScreen: React.FC<ExitScreenProps> = ({ onRestart }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-950 text-slate-100 animate-in fade-in zoom-in-95 duration-300">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 max-w-md w-full text-center shadow-2xl space-y-6 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 bg-blue-600/10 blur-3xl pointer-events-none rounded-full" />

        <div className="flex justify-center">
          <UtmachLogo className="w-16 h-16" showText={false} />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-emerald-950 text-emerald-300 border border-emerald-800 px-3 py-1 rounded-full text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Programa Finalizado
          </div>

          <h2 className="text-2xl font-extrabold text-white tracking-tight pt-2">
            Gracias por utilizar UTMACH HUB
          </h2>

          <p className="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">
            La sesión ha sido cerrada y la interfaz se encuentra bloqueada de forma segura por el sistema.
          </p>
        </div>

        <div className="pt-4 border-t border-slate-800/80 space-y-3">
          <button
            onClick={onRestart}
            className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-sky-950/50"
          >
            <RotateCcw className="w-4 h-4" />
            Reiniciar Aplicación / Iniciar de Nuevo
          </button>

          <p className="text-[10px] text-slate-500 font-mono">
            Universidad Técnica de Machala • El Oro, Ecuador
          </p>
        </div>
      </div>
    </div>
  );
};
