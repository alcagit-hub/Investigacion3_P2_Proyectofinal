import React, { useState } from 'react';
import { CampusSpace, IncidentReport, UserAccount, UserSessionStats } from '../types';
import { Navigation, Clock, AlertTriangle, ShieldAlert, CheckCircle, ThumbsUp, ThumbsDown, MessageSquarePlus, Send, MapPin, ArrowRight, Compass, Lock, Zap, Route, BarChart3, Footprints, Sparkles } from 'lucide-react';

interface HubDestinosProps {
  spaces: CampusSpace[];
  currentUser: UserAccount | null;
  incidents: IncidentReport[];
  onAddIncident: (locationId: string, locationName: string, description: string, authorEmail: string) => void;
  onVoteIncident: (incidentId: string, isConfirming: boolean, userEmail: string) => void;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  onRecordRoute?: (meters: number, destinationSpaceId: string) => void;
  sessionStats?: UserSessionStats;
}

export const HubDestinos: React.FC<HubDestinosProps> = ({
  spaces,
  currentUser,
  incidents,
  onAddIncident,
  onVoteIncident,
  onShowToast,
  onRecordRoute,
  sessionStats,
}) => {
  const [originId, setOriginId] = useState<string>(spaces[0]?.id || '');
  const [destinationId, setDestinationId] = useState<string>(spaces[1]?.id || '');

  // Active selected alternative route index (0 = Directa/Fastest, 1 = Senderos Verdes, 2 = Perimetral Techada)
  const [selectedRouteIndex, setSelectedRouteIndex] = useState<number>(0);

  // Time simulation state (default uses current real time)
  const now = new Date();
  const currentHourReal = now.getHours();
  const currentMinReal = now.getMinutes();

  const [simulatedHour, setSimulatedHour] = useState<number>(currentHourReal);
  const [simulatedMinute, setSimulatedMinute] = useState<number>(currentMinReal);
  const [useRealTime, setUseRealTime] = useState<boolean>(true);

  // Incident reporting UI state
  const [showReportForm, setShowReportForm] = useState<boolean>(false);
  const [incidentText, setIncidentText] = useState<string>('');

  const activeHour = useRealTime ? currentHourReal : simulatedHour;
  const activeMinute = useRealTime ? currentMinReal : simulatedMinute;

  // Schedule restriction rule: CLOSED between 21:00 (9 PM) and 06:00 (6 AM)
  const isClosedHours = activeHour >= 21 || activeHour < 6;

  const originSpace = spaces.find((s) => s.id === originId);
  const destinationSpace = spaces.find((s) => s.id === destinationId);

  // Calculate real Euclidean distance based on coordinates
  const calculateBaseMeters = () => {
    if (!originSpace || !destinationSpace || originSpace.id === destinationSpace.id) {
      return 0;
    }
    const dx = destinationSpace.x - originSpace.x;
    const dy = destinationSpace.y - originSpace.y;
    const euclideanDist = Math.sqrt(dx * dx + dy * dy);
    return Math.round(euclideanDist * 8.5); // 1 unit = ~8.5m
  };

  const baseMeters = calculateBaseMeters();
  const isSameSpace = originSpace?.id === destinationSpace?.id;

  // Calculate arrival time helper: startHour:startMinute + addedMinutes
  const formatArrivalTime = (startHour: number, startMinute: number, addedMinutes: number) => {
    let totalMin = startMinute + addedMinutes;
    let extraHours = Math.floor(totalMin / 60);
    let finalMin = totalMin % 60;
    let finalHour = (startHour + extraHours) % 24;

    const hh = finalHour < 10 ? `0${finalHour}` : `${finalHour}`;
    const mm = finalMin < 10 ? `0${finalMin}` : `${finalMin}`;
    return `${hh}:${mm} hs`;
  };

  // Generate 3 Alternative Route Profiles
  const baseMinutes = Math.max(1, Math.round(baseMeters / 75)); // ~75 m/min

  const routeAlternatives = [
    {
      id: 'route-direct',
      name: 'Ruta Directa Principal',
      tag: '⚡ MÁS RÁPIDA (RECOMENDADA)',
      meters: baseMeters,
      minutes: baseMinutes,
      arrivalTime: formatArrivalTime(activeHour, activeMinute, baseMinutes),
      isRecommended: true,
      description: 'Senda peatonal directa atravesando la Plaza Central Estudiantil. La opción con menor distancia y menor tiempo de traslado.',
      steps: [
        `Salga de ${originSpace?.name} (${originSpace?.block}) en dirección a la Plaza Central.`,
        `Cruce la Plaza Estudiantil siguiendo la vía directa hacia ${destinationSpace?.block}.`,
        `Ha llegado a su destino: ${destinationSpace?.name}.`
      ]
    },
    {
      id: 'route-green',
      name: 'Ruta por Senderos Verdes',
      tag: '🌿 RUTA ECOLÓGICA Y ARBOLADA',
      meters: Math.round(baseMeters * 1.25),
      minutes: baseMinutes + 2,
      arrivalTime: formatArrivalTime(activeHour, activeMinute, baseMinutes + 2),
      isRecommended: false,
      description: 'Sendero arbolado rodeando el sector de Áreas Verdes y jardines del campus. Ofrece mayor sombra y ambiente fresco.',
      steps: [
        `Salga de ${originSpace?.name} dirigiéndose hacia el perímetro del sector de Áreas Verdes.`,
        `Camine bajo los senderos arbolados hasta conectar con el pabellón de ${destinationSpace?.block}.`,
        `Acceda al edificio: ${destinationSpace?.name}.`
      ]
    },
    {
      id: 'route-covered',
      name: 'Ruta Perimetral Techada',
      tag: '☔ PASILLOS CUBIERTOS (LLUVIA / SOL)',
      meters: Math.round(baseMeters * 1.40),
      minutes: baseMinutes + 3,
      arrivalTime: formatArrivalTime(activeHour, activeMinute, baseMinutes + 3),
      isRecommended: false,
      description: 'Corredores e infraestructura cubierta rodeando los bloques académicos. Recomendada para días de lluvia intensa o sol directo.',
      steps: [
        `Salga de ${originSpace?.name} ingresando al pasillo techado del bloque académico.`,
        `Avance por el corredor perimetral bordeando la facultad hasta el área de ${destinationSpace?.block}.`,
        `Ingreso directo a ${destinationSpace?.name}.`
      ]
    }
  ];

  const currentRoute = routeAlternatives[selectedRouteIndex] || routeAlternatives[0];

  // Find active incidents for the selected origin space
  const originIncident = incidents.find((inc) => inc.locationId === originId);

  const handleRouteSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (isClosedHours) {
      alert(`Acción bloqueada por horario: A estas horas la universidad se encuentra cerrada (Horario restringido: 21:00 a 06:00).`);
      onShowToast(`A estas horas la universidad se encuentra cerrada.`, 'error');
      return;
    }

    if (isSameSpace) {
      onShowToast(`Ha seleccionado la misma ubicación para Origen y Destino.`, 'warning');
      return;
    }

    // Record stats route distance
    if (destinationSpace) {
      onRecordRoute?.(currentRoute.meters, destinationSpace.id);
    }

    onShowToast(`Ruta GPS calculada: ${currentRoute.name} (${currentRoute.meters}m, aprox. ${currentRoute.minutes} min). Hora de llegada: ${currentRoute.arrivalTime}`, 'success');
  };

  const handleCreateIncidentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentText.trim() || !originSpace || !currentUser) return;

    onAddIncident(originSpace.id, originSpace.name, incidentText.trim(), currentUser.email);
    setIncidentText('');
    setShowReportForm(false);
    onShowToast(`¡Incidente en "${originSpace.name}" reportado correctamente!`, 'warning');
  };

  const handleVote = (incidentId: string, isConfirming: boolean) => {
    if (!currentUser) return;
    onVoteIncident(incidentId, isConfirming, currentUser.email);
    onShowToast(
      isConfirming
        ? 'Confirmación registrada: El incidente sigue activo.'
        : 'Incidente desmentido/marcado como resuelto.',
      'info'
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-900/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-indigo-600 text-indigo-100 text-[10px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
                HUB DESTINOS GPS
              </span>
              <span className="text-xs text-slate-300 font-medium">Buscador Interno & Reporte Novedades</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight">
              Navegación Intracampus y Alertas en Tiempo Real
            </h2>
            <p className="text-xs text-slate-300 max-w-xl mt-1 leading-relaxed">
              Calcula la mejor ruta a pie entre cualquier espacio de la UTMACH. Cuenta con restricción de horario (21:00 - 06:00) y sistema colaborativo de verificación de incidentes.
            </p>
          </div>

          {/* Time simulation bar */}
          <div className="bg-slate-950/90 border border-slate-800 p-3.5 rounded-2xl flex flex-col gap-2.5 shrink-0 text-xs min-w-[260px]">
            <div className="flex items-center justify-between gap-3">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-sky-400" />
                Horario Activo:{' '}
                <strong className="text-sky-300 font-mono text-xs">
                  {activeHour < 10 ? `0${activeHour}` : activeHour}:
                  {activeMinute < 10 ? `0${activeMinute}` : activeMinute} hs
                </strong>
              </span>

              <button
                type="button"
                onClick={() => setUseRealTime(!useRealTime)}
                className={`text-[10px] px-2.5 py-1 rounded-lg font-bold transition-all ${
                  useRealTime
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-950'
                    : 'bg-amber-600/30 text-amber-300 border border-amber-500/40'
                }`}
              >
                {useRealTime ? 'Hora Real' : 'Hora Simulada'}
              </button>
            </div>

            {/* Time Selectors: 1. Hour, 2. Minutes */}
            {!useRealTime && (
              <div className="pt-2 border-t border-slate-800/80 space-y-2 animate-in fade-in duration-200">
                <div className="text-[10px] font-extrabold text-amber-400 uppercase tracking-wider">
                  Ajustar Hora Simulada:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {/* Step 1: Hour Selector */}
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                      1. Hora (00 - 23):
                    </label>
                    <select
                      value={simulatedHour}
                      onChange={(e) => setSimulatedHour(parseInt(e.target.value, 10))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-100 focus:outline-none focus:border-sky-500"
                    >
                      {Array.from({ length: 24 }).map((_, i) => (
                        <option key={i} value={i}>
                          {i < 10 ? `0${i}` : i}:00 ({i < 12 ? `${i === 0 ? 12 : i} AM` : `${i === 12 ? 12 : i - 12} PM`})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Step 2: Minutes Selector */}
                  <div>
                    <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                      2. Minutos (00 - 59):
                    </label>
                    <select
                      value={simulatedMinute}
                      onChange={(e) => setSimulatedMinute(parseInt(e.target.value, 10))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs font-bold text-slate-100 focus:outline-none focus:border-sky-500"
                    >
                      {Array.from({ length: 60 }).map((_, i) => (
                        <option key={i} value={i}>
                          {i < 10 ? `0${i}` : i} min
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SCHEDULE RESTRICTION ALERT (21:00 - 06:00) */}
      {isClosedHours ? (
        <div className="bg-rose-950/90 border-2 border-rose-500/80 rounded-2xl p-6 text-rose-100 shadow-2xl flex flex-col md:flex-row items-center gap-5 animate-pulse">
          <div className="p-4 rounded-2xl bg-rose-900/60 border border-rose-500/50 text-rose-300 shrink-0">
            <Lock className="w-10 h-10" />
          </div>
          <div className="space-y-1 text-center md:text-left flex-1">
            <div className="inline-block bg-rose-900 text-rose-200 text-[10px] font-black px-2.5 py-0.5 rounded uppercase tracking-wider mb-1">
              Restricción de Horario Noctuana
            </div>
            <h3 className="text-xl font-extrabold text-white">
              A estas horas la universidad se encuentra cerrada.
            </h3>
            <p className="text-xs text-rose-200/90 leading-relaxed max-w-2xl">
              El módulo Hub Destinos GPS se encuentra deshabilitado durante el horario nocturno de cierre institucional (entre las <strong>21:00 (9:00 PM)</strong> y las <strong>06:00 (6:00 AM)</strong>). El resto de la plataforma continúa funcionando normalmente.
            </p>
          </div>
        </div>
      ) : (
        /* ACTIVE GPS ROUTE SEARCH FORM */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Route Selector & Incident Reporter */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2 pb-3 border-b border-slate-800">
                <Navigation className="w-5 h-5 text-sky-400" />
                Configurar Ruta GPS
              </h3>

              <form onSubmit={handleRouteSearch} className="space-y-4">
                {/* Origin Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    1. Lugar de Origen:
                  </label>
                  <select
                    value={originId}
                    onChange={(e) => {
                      setOriginId(e.target.value);
                      setShowReportForm(false);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-sky-500 font-medium"
                  >
                    {spaces.map((space) => (
                      <option key={space.id} value={space.id}>
                        {space.name} ({space.block})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Destination Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    2. Lugar de Destino:
                  </label>
                  <select
                    value={destinationId}
                    onChange={(e) => setDestinationId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-sky-500 font-medium"
                  >
                    {spaces.map((space) => (
                      <option key={space.id} value={space.id}>
                        {space.name} ({space.block})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-sky-950/50"
                >
                  <Compass className="w-4 h-4" />
                  Calcular Ruta GPS
                </button>
              </form>

              {/* Incident Option Prompt for Selected Origin */}
              {originSpace && (
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                    <p className="text-xs text-slate-300 font-medium">
                      ¿Desea reportar un incidente en su lugar de origen (<strong>{originSpace.name}</strong>)?
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowReportForm(!showReportForm)}
                        className="px-3 py-1.5 bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold transition-colors flex-1 flex items-center justify-center gap-1.5"
                      >
                        <MessageSquarePlus className="w-3.5 h-3.5" />
                        {showReportForm ? 'Cancelar' : 'Sí, reportar incidente'}
                      </button>
                    </div>
                  </div>

                  {/* Incident Input Form */}
                  {showReportForm && (
                    <form onSubmit={handleCreateIncidentSubmit} className="space-y-2 animate-in fade-in duration-200">
                      <textarea
                        value={incidentText}
                        onChange={(e) => setIncidentText(e.target.value)}
                        placeholder={`Describa el incidente en ${originSpace.name} (ej: Lluvia intensa, Trabajos de mantenimiento, Pisos mojados)...`}
                        rows={3}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                        required
                      />
                      <button
                        type="submit"
                        className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Enviar Reporte de Incidente
                      </button>
                    </form>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Calculated Route & Cross-User Incident Verification */}
          <div className="lg:col-span-2 space-y-4">
            {/* CROSS-USER INCIDENT VERIFICATION PANEL */}
            {originIncident && (
              <div className="bg-amber-950/60 border-2 border-amber-500/70 rounded-2xl p-5 text-amber-100 shadow-xl space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between gap-2 border-b border-amber-800/80 pb-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                    <h4 className="font-extrabold text-sm text-white">
                      Incidente Activo en Origen: {originIncident.locationName}
                    </h4>
                  </div>
                  <span className="text-[10px] bg-amber-900 text-amber-200 font-mono px-2 py-0.5 rounded border border-amber-700">
                    Reportado: {originIncident.reportedAt}
                  </span>
                </div>

                <p className="text-xs text-amber-200/90 leading-relaxed font-medium bg-slate-950/50 p-3 rounded-xl border border-amber-900/50">
                  "{originIncident.description}" <span className="text-amber-400/80 font-mono text-[10px] block mt-1">— Por: {originIncident.reportedBy}</span>
                </p>

                {/* Cross-User Verification Question */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-amber-800/80">
                  <div className="text-xs text-amber-300 font-bold">
                    ¿El incidente persiste en esta ubicación?
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleVote(originIncident.id, true)}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors shadow-md"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      Confirmar ({originIncident.confirms})
                    </button>

                    <button
                      onClick={() => handleVote(originIncident.id, false)}
                      className="px-3 py-1.5 bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors shadow-md"
                    >
                      <ThumbsDown className="w-3.5 h-3.5" />
                      Desmentir ({originIncident.denials})
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ROUTE DISPLAY DETAILS & 3 ALTERNATIVE ROUTES */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-sky-400" />
                  <h3 className="font-bold text-base text-slate-100">
                    Opciones de Ruta GPS y Sugerencia
                  </h3>
                </div>
                <span className={`text-xs font-mono px-2.5 py-1 rounded-lg border font-bold ${
                  isSameSpace
                    ? 'bg-amber-950 text-amber-300 border-amber-800'
                    : 'bg-blue-950 text-sky-300 border-blue-800'
                }`}>
                  {isSameSpace
                    ? '0 min (0 m) - Misma ubicación'
                    : `Distancia Directa: ${baseMeters}m`}
                </span>
              </div>

              {/* 3 ALTERNATIVE ROUTES SELECTOR CARDS */}
              {!isSameSpace && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Route className="w-4 h-4 text-sky-400" />
                      3 Rutas Alternativas Calculadas:
                    </span>
                    <span className="text-[11px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
                      <Zap className="w-3 h-3 text-emerald-400" />
                      Sugerencia: Ruta 1 es la más rápida
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {routeAlternatives.map((route, idx) => {
                      const isSelected = selectedRouteIndex === idx;

                      return (
                        <div
                          key={route.id}
                          onClick={() => setSelectedRouteIndex(idx)}
                          className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between relative ${
                            isSelected
                              ? 'bg-slate-950 border-sky-500 shadow-lg shadow-sky-950/40 ring-1 ring-sky-500'
                              : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-950/80'
                          }`}
                        >
                          {route.isRecommended && (
                            <span className="absolute -top-2.5 left-3 bg-amber-500 text-slate-950 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 shadow">
                              <Sparkles className="w-2.5 h-2.5" /> Más Rápida
                            </span>
                          )}

                          <div>
                            <div className="text-[10px] font-extrabold text-sky-400 uppercase tracking-wider mb-1">
                              {route.tag}
                            </div>
                            <h4 className="font-bold text-slate-100 text-xs">{route.name}</h4>
                            <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                              {route.description}
                            </p>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-400 font-medium">Tiempo:</span>
                              <strong className="text-sky-300 font-bold">~{route.minutes} min</strong>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-400 font-medium">Distancia:</span>
                              <strong className="text-slate-200 font-mono">{route.meters} m</strong>
                            </div>
                            <div className="flex items-center justify-between text-xs pt-0.5 border-t border-slate-900">
                              <span className="text-slate-400 font-medium flex items-center gap-1">
                                <Clock className="w-3 h-3 text-amber-400" /> Hora llegada:
                              </span>
                              <strong className="text-emerald-400 font-extrabold font-mono">{route.arrivalTime}</strong>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Route Summary header */}
              <div className="flex items-center justify-between p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Origen</span>
                  <h4 className="font-bold text-sky-300 text-sm">{originSpace?.name}</h4>
                  <p className="text-xs text-slate-400">{originSpace?.block} • Coord ({originSpace?.x}, {originSpace?.y})</p>
                </div>

                <div className="flex flex-col items-center">
                  <ArrowRight className="w-6 h-6 text-sky-400 shrink-0" />
                  <span className="text-[10px] font-mono text-emerald-400 mt-0.5 font-bold">
                    Hora llegada: {currentRoute.arrivalTime}
                  </span>
                </div>

                <div className="space-y-1 text-right">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Destino</span>
                  <h4 className="font-bold text-emerald-300 text-sm">{destinationSpace?.name}</h4>
                  <p className="text-xs text-slate-400">{destinationSpace?.block} • Coord ({destinationSpace?.x}, {destinationSpace?.y})</p>
                </div>
              </div>

              {/* Step by Step directions */}
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Indicaciones paso a paso ({currentRoute.name}):
                </h4>
                {isSameSpace ? (
                  <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs text-amber-300">
                    Ha seleccionado la misma ubicación para Origen y Destino ({originSpace?.name}). No se requiere desplazamiento.
                  </div>
                ) : (
                  <div className="space-y-2 text-xs text-slate-300">
                    {currentRoute.steps.map((stepText, sIdx) => (
                      <div key={sIdx} className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-start gap-3">
                        <span className="w-5 h-5 rounded-full bg-blue-900 text-sky-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          {sIdx + 1}
                        </span>
                        <p className="leading-relaxed">{stepText}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* USER RECORRIDO STATISTICS PANEL (Teacher & Guest Profiles) */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h3 className="font-bold text-sm text-slate-100">
                      Estadísticas de Recorrido del Usuario ({currentUser?.role === 'teacher' ? 'Perfil Docente' : 'Perfil Invitado'})
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Sitios más visitados y distancia total acumulada durante el ciclo del sistema.
                    </p>
                  </div>
                </div>
                <span className="text-[10px] bg-slate-950 text-slate-400 border border-slate-800 px-2 py-1 rounded font-mono">
                  Reinicio cada 60s
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Distance Stat Card */}
                <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400 shrink-0">
                    <Footprints className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      Distancia Total Recorrida
                    </span>
                    <div className="text-xl font-extrabold text-slate-100 font-mono mt-0.5">
                      {((sessionStats?.totalMeters || 0) / 1000).toFixed(2)} km
                      <span className="text-xs text-emerald-400 font-normal ml-2">({sessionStats?.totalMeters || 0} m)</span>
                    </div>
                  </div>
                </div>

                {/* Most Visited Places List */}
                <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Sitios Más Visitados en esta Sesión:
                  </span>
                  {sessionStats && Object.keys(sessionStats.visitedPlaces).length > 0 ? (
                    <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
                      {Object.entries(sessionStats.visitedPlaces)
                        .sort(([, a], [, b]) => b - a)
                        .map(([spId, count]) => {
                          const targetSp = spaces.find((s) => s.id === spId);
                          return (
                            <div key={spId} className="flex items-center justify-between text-xs py-1 border-b border-slate-900">
                              <span className="text-slate-200 font-medium truncate">{targetSp?.name || spId}</span>
                              <span className="text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded-full">
                                {count} {count === 1 ? 'visita' : 'visitas'}
                              </span>
                            </div>
                          );
                        })}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic py-2">
                      Aún no ha calculado rutas en esta sesión. Seleccione orígenes/destinos y presione "Calcular Ruta GPS".
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
