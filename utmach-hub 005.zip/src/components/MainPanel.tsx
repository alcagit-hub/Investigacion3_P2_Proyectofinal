import React, { useState } from 'react';
import { CampusSpace, UserAccount, UserSessionStats } from '../types';
import { CampusMap2D } from './CampusMap2D';
import { Building2, Trees, Coffee, DoorClosed, MapPin, Search, CheckCircle2, AlertCircle, Sparkles, Filter, Lock, BarChart3, Footprints } from 'lucide-react';

interface MainPanelProps {
  spaces: CampusSpace[];
  onNavigateToSpace?: (space: CampusSpace) => void;
  sessionStats?: UserSessionStats;
  currentUser?: UserAccount | null;
}

export const MainPanel: React.FC<MainPanelProps> = ({
  spaces,
  onNavigateToSpace,
  sessionStats,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<string>('todos');

  // Main Panel contains the FULL COMBINATION of spaces
  const filteredSpaces = spaces.filter((space) => {
    const matchesSearch =
      space.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      space.block.toLowerCase().includes(searchTerm.toLowerCase()) ||
      space.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType =
      selectedTypeFilter === 'todos' || space.type === selectedTypeFilter;

    return matchesSearch && matchesType;
  });

  const getSpaceIcon = (type: CampusSpace['type']) => {
    switch (type) {
      case 'aula':
        return <Building2 className="w-5 h-5 text-sky-400" />;
      case 'area_verde':
        return <Trees className="w-5 h-5 text-emerald-400" />;
      case 'bar':
        return <Coffee className="w-5 h-5 text-rose-400" />;
      case 'bano':
        return <DoorClosed className="w-5 h-5 text-indigo-400" />;
      case 'entrada_principal':
      case 'entrada_trasera':
        return <MapPin className="w-5 h-5 text-amber-400" />;
    }
  };

  const getTypeLabel = (type: CampusSpace['type']) => {
    switch (type) {
      case 'aula':
        return 'Aula Académica';
      case 'area_verde':
        return 'Área Verde';
      case 'bar':
        return 'Bar / Cafetería';
      case 'bano':
        return 'Servicios Higiénicos';
      case 'entrada_principal':
        return 'Entrada Principal';
      case 'entrada_trasera':
        return 'Entrada Trasera';
    }
  };

  const getTypeBadgeClass = (type: CampusSpace['type']) => {
    switch (type) {
      case 'aula':
        return 'bg-sky-950 text-sky-300 border-sky-800';
      case 'area_verde':
        return 'bg-emerald-950 text-emerald-300 border-emerald-800';
      case 'bar':
        return 'bg-rose-950 text-rose-300 border-rose-800';
      case 'bano':
        return 'bg-indigo-950 text-indigo-300 border-indigo-800';
      case 'entrada_principal':
      case 'entrada_trasera':
        return 'bg-amber-950 text-amber-300 border-amber-800';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Title & Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-900/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-blue-600 text-blue-100 text-[10px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
              UTMACH HUB
            </span>
            <span className="text-xs text-sky-300 font-medium">Panel Principal (Vista General Completa)</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            Universidad Técnica de Machala
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl mt-1 leading-relaxed">
            Explora la infraestructura universitaria completa: Aulas, Áreas Verdes, Bar, Baños y Entradas del campus central en una sola vista unificada.
          </p>
        </div>
      </div>

      {/* 2D Static Campus Map Section */}
      <CampusMap2D spaces={spaces} />

      {/* USER RECORRIDO STATISTICS CARD (Teacher & Guest Profiles) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm text-slate-100">
                Estadísticas de Recorrido del Usuario ({currentUser?.role === 'teacher' ? 'Perfil Docente' : 'Perfil Invitado'})
              </h3>
              <p className="text-[11px] text-slate-400">
                Sitios más visitados y kilómetros recorridos acumulados durante la sesión actual.
              </p>
            </div>
          </div>
          <span className="text-[10px] bg-slate-950 text-slate-400 border border-slate-800 px-2.5 py-1 rounded font-mono">
            Reinicio cada 60s
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Distance Stat Card */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-center gap-4">
            <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400 shrink-0">
              <Footprints className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                Distancia Recorrida Acumulada
              </span>
              <div className="text-xl font-extrabold text-slate-100 font-mono mt-0.5">
                {((sessionStats?.totalMeters || 0) / 1000).toFixed(2)} km
                <span className="text-xs text-emerald-400 font-normal ml-2">({sessionStats?.totalMeters || 0} m)</span>
              </div>
            </div>
          </div>

          {/* Most Visited Places List */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
              Sitios Más Visitados en esta Sesión:
            </span>
            {sessionStats && Object.keys(sessionStats.visitedPlaces).length > 0 ? (
              <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
                {Object.entries(sessionStats.visitedPlaces)
                  .sort(([, a], [, b]) => b - a)
                  .map(([spId, count]) => {
                    const targetSp = spaces.find((s) => s.id === spId);
                    return (
                      <div key={spId} className="flex items-center justify-between text-xs py-1 border-b border-slate-900">
                        <span className="text-slate-200 font-medium truncate">{targetSp?.name || spId}</span>
                        <span className="text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-800 px-2 py-0.5 rounded-full">
                          {count} {count === 1 ? 'visita' : 'visitas'}
                        </span>
                      </div>
                    );
                  })}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic py-2">
                Aún no ha calculado rutas en esta sesión. Ingrese a "Hub Destinos GPS" para calcular trayectos.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Exclusive Complete Places Directory Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-sky-400" />
              Directorio Unificado del Panel Principal
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Combinación exclusiva de Aulas, Áreas Verdes, Bar, Baños y Entradas del Campus Central.
            </p>
          </div>

          {/* Search & Filter controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar lugar o bloque..."
                className="bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 w-48 sm:w-60"
              />
            </div>

            {/* Type Filter Select */}
            <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedTypeFilter}
                onChange={(e) => setSelectedTypeFilter(e.target.value)}
                className="bg-transparent text-slate-200 focus:outline-none font-medium cursor-pointer"
              >
                <option value="todos">Todos los espacios ({spaces.length})</option>
                <option value="aula">Aulas</option>
                <option value="area_verde">Áreas Verdes</option>
                <option value="bar">Bar / Cafetería</option>
                <option value="bano">Baños</option>
                <option value="entrada_principal">Entrada Principal</option>
                <option value="entrada_trasera">Entrada Trasera</option>
              </select>
            </div>
          </div>
        </div>

        {/* Space Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSpaces.map((space) => {
            const isClassroom = space.type === 'aula';

            return (
              <div
                key={space.id}
                className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition-all shadow-md group hover:shadow-sky-950/20"
              >
                <div>
                  {/* Category & Status Row */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getTypeBadgeClass(space.type)}`}>
                      {getTypeLabel(space.type)}
                    </span>

                    {/* Classroom Occupation Status */}
                    {isClassroom ? (
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                        space.isOccupied
                          ? 'bg-amber-950/80 text-amber-300 border-amber-800/80'
                          : 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
                      }`}>
                        {space.isOccupied ? (
                          <>
                            <AlertCircle className="w-3 h-3 text-amber-400" />
                            Ocupada
                          </>
                        ) : (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            Desocupada
                          </>
                        )}
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-500 font-medium italic">
                        Ubicación fija
                      </span>
                    )}
                  </div>

                  {/* Title & Icon */}
                  <div className="flex items-start gap-2.5 mt-1">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0">
                      {getSpaceIcon(space.type)}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-100 text-sm group-hover:text-sky-300 transition-colors">
                        {space.name}
                      </h4>
                      <p className="text-[11px] text-sky-400/90 font-medium">
                        {space.block} {space.floor ? `• ${space.floor}` : ''}
                      </p>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-400 mt-2.5 leading-relaxed line-clamp-2">
                    {space.description}
                  </p>

                  {/* Occupant Email if occupied */}
                  {isClassroom && space.isOccupied && space.occupiedBy && (
                    <div className="mt-2.5 p-2 bg-amber-950/30 border border-amber-900/50 rounded-lg text-[11px] text-amber-300 flex items-center gap-1.5">
                      <Lock className="w-3 h-3 text-amber-400 shrink-0" />
                      <span className="truncate">Ocupado por: <strong>{space.occupiedBy}</strong></span>
                    </div>
                  )}
                </div>

                {/* Card Footer info */}
                <div className="mt-4 pt-3 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-500">
                  <span>UTMACH Campus Central</span>
                  {space.capacity && <span>Capacidad: {space.capacity} pers.</span>}
                </div>
              </div>
            );
          })}
        </div>

        {filteredSpaces.length === 0 && (
          <div className="text-center py-10 text-slate-400 text-xs bg-slate-950 rounded-xl border border-slate-800">
            No se encontraron espacios que coincidan con la búsqueda "{searchTerm}".
          </div>
        )}
      </div>
    </div>
  );
};
