import React from 'react';
import { Timer, RefreshCw, AlertCircle, Sparkles } from 'lucide-react';

interface MasterTimerBannerProps {
  secondsLeft: number;
  onForceReset?: () => void;
}

export const MasterTimerBanner: React.FC<MasterTimerBannerProps> = ({ secondsLeft, onForceReset }) => {
  const progressPercent = (secondsLeft / 60) * 100;
  const formattedTime = `00:${secondsLeft < 10 ? '0' : ''}${secondsLeft}`;

  const isLowTime = secondsLeft <= 10;

  return (
    <div className={`transition-all duration-300 rounded-xl p-3 border shadow-lg ${
      isLowTime
        ? 'bg-rose-950/80 border-rose-500/60 text-rose-200 animate-pulse'
        : 'bg-slate-900/90 border-blue-800/60 text-slate-200'
    }`}>
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded-lg ${isLowTime ? 'bg-rose-900/60 text-rose-300' : 'bg-blue-900/50 text-blue-400'}`}>
            <Timer className={`w-5 h-5 ${isLowTime ? 'animate-spin' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold tracking-wider uppercase text-blue-400">
                Temporizador Maestro Global
              </span>
              <span className="text-[10px] bg-blue-950 text-blue-300 px-1.5 py-0.2 rounded border border-blue-800">
                60s Ciclo
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden sm:block">
              Llegado a 00:00 reinicia aulas, mensajes Vibe, incidentes y sesión temporal.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <span className={`font-mono text-xl font-extrabold tracking-widest ${
              isLowTime ? 'text-rose-400' : 'text-sky-300'
            }`}>
              {formattedTime}
            </span>
            <span className="text-[9px] text-slate-400 uppercase tracking-tighter">
              Restablecimiento
            </span>
          </div>

          {onForceReset && (
            <button
              onClick={onForceReset}
              title="Reiniciar manualmente ciclo de 60s"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:border-slate-500 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-800/80 rounded-full h-1.5 mt-2.5 overflow-hidden border border-slate-700/50">
        <div
          className={`h-full transition-all duration-1000 ease-linear rounded-full ${
            isLowTime
              ? 'bg-gradient-to-r from-rose-500 to-amber-400'
              : 'bg-gradient-to-r from-sky-500 via-blue-500 to-indigo-500'
          }`}
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </div>
  );
};
