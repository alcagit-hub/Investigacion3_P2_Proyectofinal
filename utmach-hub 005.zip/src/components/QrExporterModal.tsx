import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { X, Download, QrCode, Printer, Check, Copy, Sparkles, ExternalLink } from 'lucide-react';
import { CampusSpace } from '../types';

interface QrExporterModalProps {
  spaces: CampusSpace[];
  isOpen: boolean;
  onClose: () => void;
}

interface QrItem {
  space: CampusSpace;
  dataUrl: string;
}

export const QrExporterModal: React.FC<QrExporterModalProps> = ({ spaces, isOpen, onClose }) => {
  const [qrItems, setQrItems] = useState<QrItem[]>([]);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  // Filter classrooms (Aulas) that have QR Tokens
  const classrooms = spaces.filter((s) => s.type === 'aula' && s.qrToken);

  useEffect(() => {
    if (!isOpen) return;

    const generateQrCodes = async () => {
      const items: QrItem[] = [];
      for (const classroom of classrooms) {
        if (classroom.qrToken) {
          try {
            const url = await QRCode.toDataURL(classroom.qrToken, {
              width: 300,
              margin: 2,
              color: {
                dark: '#002855',
                light: '#ffffff'
              }
            });
            items.push({ space: classroom, dataUrl: url });
          } catch (err) {
            console.error('Error generating QR code:', err);
          }
        }
      }
      setQrItems(items);
    };

    generateQrCodes();
  }, [isOpen, spaces]);

  const handleCopy = (token: string) => {
    navigator.clipboard.writeText(token);
    setCopiedToken(token);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const handleDownloadSingle = (dataUrl: string, fileName: string) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `${fileName}-QR-UTMACH.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintAll = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-900/60 text-sky-400 border border-blue-700/50">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2">
                Documento de Códigos QR Oficiales de Aulas
                <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono">
                  Pruebas de Escaneo
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Generador y exportador en PNG de los tokens únicos de aulas para realizar pruebas visuales con la cámara.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintAll}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4 text-sky-400" />
              Imprimir / PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 print:p-0">
          <div className="bg-sky-950/40 border border-sky-800/60 p-4 rounded-xl text-xs text-sky-200 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sky-100 mb-1">
                ¿Cómo realizar la prueba de lectura por cámara?
              </p>
              <p className="text-sky-300/90 leading-relaxed">
                Abra la opción <strong>"Escanear QR"</strong> en el módulo de Gestión de Espacios y apunte la cámara de su teléfono o webcam hacia uno de estos códigos QR renderizados en pantalla, o descargue la imagen PNG para escanearla.
              </p>
            </div>
          </div>

          {/* Grid of Classroom QR Codes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {qrItems.map(({ space, dataUrl }) => (
              <div
                key={space.id}
                className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center text-center shadow-lg hover:border-slate-700 transition-all group"
              >
                <div className="mb-2">
                  <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                    {space.block}
                  </span>
                  <h4 className="font-bold text-slate-100 text-sm mt-1">{space.name}</h4>
                </div>

                {/* QR Image Box */}
                <div className="bg-white p-3 rounded-xl border border-slate-200 my-2 shadow-md">
                  <img src={dataUrl} alt={`QR ${space.name}`} className="w-36 h-36 object-contain" />
                </div>

                {/* Token Label */}
                <div className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 my-2 font-mono text-[11px] text-amber-300 flex items-center justify-between">
                  <span className="truncate">{space.qrToken}</span>
                  <button
                    onClick={() => handleCopy(space.qrToken!)}
                    className="p-1 hover:text-white transition-colors ml-1 shrink-0"
                    title="Copiar token"
                  >
                    {copiedToken === space.qrToken ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </button>
                </div>

                {/* Action Buttons */}
                <button
                  onClick={() => handleDownloadSingle(dataUrl, space.id)}
                  className="w-full mt-1 bg-blue-900/40 hover:bg-blue-800/60 text-sky-300 border border-blue-700/50 hover:border-blue-500 rounded-lg py-1.5 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  Descargar PNG
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between shrink-0">
          <span>Universidad Técnica de Machala • Sistema UTMACH HUB</span>
          <span className="font-mono text-sky-400">{classrooms.length} Aulas con Token QR</span>
        </div>
      </div>
    </div>
  );
};
