import React, { useEffect, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, X, AlertTriangle, CheckCircle2, RefreshCw, KeyRound, Lock, ShieldAlert } from 'lucide-react';
import { CampusSpace, UserAccount } from '../types';

interface QrScannerModalProps {
  targetSpace: CampusSpace;
  currentUser: UserAccount | null;
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (scannedToken: string) => void;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  targetSpace,
  currentUser,
  isOpen,
  onClose,
  onScanSuccess,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualTokenInput, setManualTokenInput] = useState<string>('');
  const [isScanningActive, setIsScanningActive] = useState<boolean>(true);

  // Initialize camera stream when modal opens
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        setCameraError(null);
        setHasCameraPermission(null);

        // Native mediaDevices getUserMedia API call
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute('playsinline', 'true'); // required for iOS safari
          await videoRef.current.play();
          setHasCameraPermission(true);
          scanFrame();
        }
      } catch (err: any) {
        console.warn('Camera access denied or unassigned:', err);
        setHasCameraPermission(false);
        setCameraError(
          err.message || 'No se pudo acceder a la cámara del dispositivo. Puede usar la simulación manual de token.'
        );
      }
    };

    startCamera();

    return () => {
      stopCamera();
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen]);

  const stopCamera = () => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  // Continuous frame analysis with jsQR
  const scanFrame = () => {
    if (!isScanningActive) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video && video.readyState === video.HAVE_ENOUGH_DATA && canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          console.log('QR Code successfully detected via camera:', code.data);
          stopCamera();
          onScanSuccess(code.data.trim());
          return;
        }
      }
    }

    animFrameIdRef.current = requestAnimationFrame(scanFrame);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualTokenInput.trim()) return;
    stopCamera();
    onScanSuccess(manualTokenInput.trim());
  };

  const handleQuickInsertToken = () => {
    if (targetSpace.qrToken) {
      setManualTokenInput(targetSpace.qrToken);
      stopCamera();
      onScanSuccess(targetSpace.qrToken);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl relative flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-900/60 text-sky-400 border border-blue-700/50">
              <Camera className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-100">
                Escanear Código QR por Cámara
              </h3>
              <p className="text-xs text-slate-400">
                Espacio objetivo: <strong className="text-sky-300">{targetSpace.name}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 flex-1">
          {/* Target space info banner */}
          <div className="p-3 bg-slate-800/60 border border-slate-700 rounded-xl flex items-center justify-between text-xs">
            <div className="space-y-0.5">
              <span className="text-slate-400 block">Acción requerida para aula:</span>
              <span className="font-semibold text-slate-200">{targetSpace.name} ({targetSpace.block})</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block">Estado actual:</span>
              <span className={`font-bold ${targetSpace.isOccupied ? 'text-amber-400' : 'text-emerald-400'}`}>
                {targetSpace.isOccupied ? 'Ocupada' : 'Desocupada'}
              </span>
            </div>
          </div>

          {/* Camera Viewfinder */}
          <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center shadow-inner">
            {/* Hidden canvas used for video frame capturing */}
            <canvas ref={canvasRef} className="hidden" />

            {/* Video stream element */}
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              muted
            />

            {/* Viewfinder overlay frame */}
            <div className="absolute inset-0 border-2 border-sky-500/40 rounded-xl pointer-events-none flex items-center justify-center">
              <div className="w-48 h-48 border-2 border-sky-400 border-dashed rounded-lg relative flex items-center justify-center bg-sky-500/5">
                <div className="scan-line" />
                <span className="text-[10px] text-sky-300 bg-slate-900/90 px-2 py-0.5 rounded border border-sky-800 font-mono">
                  Alinee el código QR
                </span>
              </div>
            </div>

            {/* Camera Permission Loading State */}
            {hasCameraPermission === null && (
              <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center gap-2 text-center p-4">
                <RefreshCw className="w-6 h-6 text-sky-400 animate-spin" />
                <span className="text-xs font-medium text-slate-300">
                  Iniciando cámara del dispositivo...
                </span>
              </div>
            )}

            {/* Camera Permission Error State */}
            {hasCameraPermission === false && (
              <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center gap-2 text-center p-4">
                <ShieldAlert className="w-8 h-8 text-amber-400" />
                <span className="text-xs font-semibold text-amber-300">
                  Cámara no disponible en vista previa
                </span>
                <p className="text-[11px] text-slate-400 max-w-xs">
                  {cameraError}
                </p>
              </div>
            )}
          </div>

          {/* Fallback Manual Token Option */}
          <div className="pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-sky-400" />
                Ingreso directo de Token o Simulación
              </label>

              {targetSpace.qrToken && (
                <button
                  type="button"
                  onClick={handleQuickInsertToken}
                  className="text-[11px] text-sky-400 hover:text-sky-300 underline font-medium"
                >
                  Usar Token exacto: ({targetSpace.qrToken})
                </button>
              )}
            </div>

            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <input
                type="text"
                value={manualTokenInput}
                onChange={(e) => setManualTokenInput(e.target.value)}
                placeholder="Ej. UTMACH-AULA-101"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
              />
              <button
                type="submit"
                className="bg-sky-600 hover:bg-sky-500 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors shrink-0 flex items-center gap-1"
              >
                Validar
              </button>
            </form>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-[11px] text-slate-400 text-center flex items-center justify-center gap-2">
          <Lock className="w-3.5 h-3.5 text-blue-400" />
          <span>Seguridad UTMACH: Lectura de token mediante cámara en tiempo real.</span>
        </div>
      </div>
    </div>
  );
};
