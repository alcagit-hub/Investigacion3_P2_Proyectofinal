import React from 'react';
import { ActiveModule, UserAccount } from '../types';
import { UtmachLogo } from './UtmachLogo';
import { LayoutDashboard, Building2, Navigation, MessageSquare, QrCode, LogOut, Power, ShieldCheck, UserCheck, Timer, Sparkles } from 'lucide-react';

interface SidebarProps {
  activeModule: ActiveModule;
  onSelectModule: (module: ActiveModule) => void;
  currentUser: UserAccount | null;
  secondsLeft: number;
  onLogout: () => void;
  onExitApp: () => void;
  onOpenAuthModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  onSelectModule,
  currentUser,
  secondsLeft,
  onLogout,
  onExitApp,
  onOpenAuthModal,
}) => {
  const isTeacher = currentUser?.role === 'teacher';

  return (
    <aside className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col justify-between h-screen sticky top-0 shrink-0 z-30 shadow-2xl">
      {/* Top Branding Section */}
      <div>
        <div className="p-5 border-b border-slate-800/80 bg-gradient-to-b from-blue-950/60 to-transparent">
          <UtmachLogo className="w-10 h-10" showText={true} />
        </div>

        {/* User Account Badge */}
        <div className="p-4 border-b border-slate-800/60 bg-slate-950/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`p-1.5 rounded-lg border ${
                isTeacher ? 'bg-emerald-950 border-emerald-800 text-emerald-400' : 'bg-sky-950 border-sky-800 text-sky-400'
              }`}>
                {isTeacher ? <ShieldCheck className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-100 truncate max-w-[130px]">
                  {currentUser?.name || 'Invitado UTMACH'}
                </span>
                <span className={`text-[10px] font-semibold ${isTeacher ? 'text-emerald-400' : 'text-sky-400'}`}>
                  {isTeacher ? 'Rol: Docente' : 'Rol: Invitado'}
                </span>
              </div>
            </div>

            <button
              onClick={onOpenAuthModal}
              className="text-[10px] text-sky-400 hover:text-sky-300 font-semibold underline"
            >
              Cambiar
            </button>
          </div>
        </div>

        {/* Navigation Menu Links */}
        <nav className="p-3 space-y-1.5 mt-2">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2">
            Navegación Principal
          </div>

          {/* 1. Panel Principal */}
          <button
            onClick={() => onSelectModule('panel_principal')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeModule === 'panel_principal'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-950/50 border border-sky-400/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Panel Principal</span>
          </button>

          {/* 2. Gestión de Espacios */}
          <button
            onClick={() => onSelectModule('gestion_espacios')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeModule === 'gestion_espacios'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-950/50 border border-sky-400/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Gestión de Espacios</span>
          </button>

          {/* 3. Hub Destinos GPS */}
          <button
            onClick={() => onSelectModule('hub_destinos')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeModule === 'hub_destinos'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-950/50 border border-sky-400/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <Navigation className="w-4 h-4" />
            <span>Hub Destinos GPS</span>
          </button>

          {/* 4. Vibe UTMACH Feed */}
          <button
            onClick={() => onSelectModule('vibe_utmach')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeModule === 'vibe_utmach'
                ? 'bg-sky-600 text-white shadow-lg shadow-sky-950/50 border border-sky-400/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Red Vibe UTMACH</span>
          </button>

          {/* 5. Documento / Exportar QR (Solo para docentes) */}
          {isTeacher && (
            <button
              onClick={() => onSelectModule('qr_export')}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeModule === 'qr_export'
                  ? 'bg-sky-600 text-white shadow-lg shadow-sky-950/50 border border-sky-400/30'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <QrCode className="w-4 h-4 text-amber-400" />
              <span>Códigos QR Pruebas</span>
            </button>
          )}
        </nav>
      </div>

      {/* Bottom Section: Master Timer Indicator & Program Control */}
      <div className="p-3 border-t border-slate-800/80 space-y-2 bg-slate-950/60">
        {/* Compact Master Timer Widget */}
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold uppercase tracking-wider">
            <span className="flex items-center gap-1">
              <Timer className="w-3 h-3 text-sky-400 animate-pulse" />
              Temporizador Maestro
            </span>
            <span className="font-mono text-sky-300 font-extrabold text-xs">
              00:{secondsLeft < 10 ? '0' : ''}{secondsLeft}s
            </span>
          </div>
          <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden">
            <div
              className="bg-sky-500 h-full transition-all duration-1000 ease-linear"
              style={{ width: `${(secondsLeft / 60) * 100}%` }}
            />
          </div>
        </div>

        {/* Session Actions */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={onLogout}
            className="py-2 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/80 rounded-xl text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5 text-amber-400" />
            <span>Cerrar Sesión</span>
          </button>

          <button
            onClick={onExitApp}
            className="py-2 px-2.5 bg-rose-950/60 hover:bg-rose-900/80 text-rose-200 border border-rose-800/60 rounded-xl text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Power className="w-3.5 h-3.5 text-rose-400" />
            <span>Salir</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
