import React, { useState } from 'react';
import { CampusSpace, UserAccount } from '../types';
import { QrScannerModal } from './QrScannerModal';
import { QrExporterModal } from './QrExporterModal';
import { Building2, Trees, Camera, ShieldAlert, CheckCircle2, AlertCircle, Lock, Unlock, QrCode, Sparkles, Filter, Info, ShieldCheck } from 'lucide-react';

interface SpaceManagementProps {
  spaces: CampusSpace[];
  currentUser: UserAccount | null;
  onUpdateSpaceOccupation: (spaceId: string, isOccupied: boolean, teacherEmail: string | null) => void;
  onShowToast: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const SpaceManagement: React.FC<SpaceManagementProps> = ({
  spaces,
  currentUser,
  onUpdateSpaceOccupation,
  onShowToast,
}) => {
  const isTeacher = currentUser?.role === 'teacher';

  // Catálogo Unificado de Espacios contains ONLY Aulas and Áreas Verdes
  const catalogSpaces = spaces.filter((s) => s.type === 'aula' || s.type === 'area_verde');

  const [filterType, setFilterType] = useState<'todos' | 'aula' | 'area_verde'>('todos');
  const [selectedSpaceForScan, setSelectedSpaceForScan] = useState<CampusSpace | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isExporterOpen, setIsExporterOpen] = useState<boolean>(false);

  const displayedSpaces = catalogSpaces.filter((space) => {
    if (filterType === 'todos') return true;
    return space.type === filterType;
  });

  const handleInitiateScan = (space: CampusSpace) => {
    // Rule: Non-classrooms cannot be occupied
    if (space.type !== 'aula') {
      alert(`Acción denegada: El espacio "${space.name}" es un área verde y no es un aula académica. Por reglamentación institucional, únicamente las aulas pueden ser marcadas como ocupadas.`);
      onShowToast(`Este espacio no es un aula y no puede ser ocupado.`, 'warning');
      return;
    }

    // Rule: Must be logged in as Teacher to occupy or unmark
    if (!currentUser || currentUser.role !== 'teacher') {
      alert(`Acción denegada: Solamente los usuarios autenticados como DOCENTE tienen la facultad de cambiar el estado de ocupación de las aulas.`);
      onShowToast(`Se requieren permisos de Docente para esta acción.`, 'error');
      return;
    }

    // Rule: If classroom is currently occupied, verify if it's the SAME teacher trying to unmark it
    if (space.isOccupied) {
      if (space.occupiedBy !== currentUser.email) {
        alert(`Acción denegada: El aula "${space.name}" fue ocupada por el docente (${space.occupiedBy}). Únicamente dicho docente tiene la facultad de desmarcarla.`);
        onShowToast(`Solo el docente (${space.occupiedBy}) que ocupó esta aula puede desmarcarla.`, 'error');
        return;
      }
    }

    // If validations pass, open scanner modal
    setSelectedSpaceForScan(space);
    setIsScannerOpen(true);
  };

  const handleScanSuccess = (scannedToken: string) => {
    setIsScannerOpen(false);
    if (!selectedSpaceForScan || !currentUser) return;

    const space = selectedSpaceForScan;

    // Check if scanned token matches classroom token
    if (scannedToken !== space.qrToken) {
      alert(`Código QR Inválido: El código QR escaneado (token: "${scannedToken}") no corresponde al token asignado a esta aula ("${space.qrToken}"). Por favor escanee el código QR correcto.`);
      onShowToast(`Código QR no corresponde a ${space.name}`, 'error');
      return;
    }

    // Process occupation state change
    if (!space.isOccupied) {
      // Mark as occupied
      onUpdateSpaceOccupation(space.id, true, currentUser.email);
      onShowToast(`¡Aula ${space.name} marcada correctamente como OCUPADA!`, 'success');
    } else {
      // Unmark (Liberate classroom)
      onUpdateSpaceOccupation(space.id, false, null);
      onShowToast(`¡Aula ${space.name} desmarcada y LIBERADA correctamente!`, 'info');
    }

    setSelectedSpaceForScan(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-sky-950 border border-blue-800/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-sky-600 text-sky-100 text-[10px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
                MÓDULO DE GESTIÓN DE ESPACIOS
              </span>
              <span className="text-xs text-slate-300 font-medium">Catálogo Unificado</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight">
              Control de Aulas y Áreas Verdes UTMACH
            </h2>
            <p className="text-xs text-slate-300 max-w-xl mt-1 leading-relaxed">
              Catálogo delimitado que contiene <strong>ÚNICAMENTE Aulas y Áreas Verdes</strong>. Visualización en tiempo real del estado de ocupación de las aulas.
              {isTeacher && ' Los docentes pueden gestionar la ocupación mediante escaneo QR por cámara.'}
            </p>
          </div>

          {isTeacher && (
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setIsExporterOpen(true)}
                className="bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-lg border border-sky-400/40 flex items-center gap-2 transition-all hover:scale-105"
              >
                <QrCode className="w-4 h-4" />
                Ver/Exportar QR de Aulas para Pruebas
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Filter and Role Indicator Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-sky-400" />
          <span className="text-xs font-semibold text-slate-300">Filtrar catálogo:</span>
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setFilterType('todos')}
              className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                filterType === 'todos' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Todos ({catalogSpaces.length})
            </button>
            <button
              onClick={() => setFilterType('aula')}
              className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                filterType === 'aula' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Aulas ({catalogSpaces.filter((s) => s.type === 'aula').length})
            </button>
            <button
              onClick={() => setFilterType('area_verde')}
              className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                filterType === 'area_verde' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Áreas Verdes ({catalogSpaces.filter((s) => s.type === 'area_verde').length})
            </button>
          </div>
        </div>

        {/* Current User Role Notice */}
        <div className="flex items-center gap-2 text-xs bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl">
          <ShieldCheck className="w-4 h-4 text-sky-400" />
          <span className="text-slate-400">Permiso activo:</span>
          <span className={`font-bold ${currentUser?.role === 'teacher' ? 'text-emerald-400' : 'text-amber-400'}`}>
            {currentUser?.role === 'teacher' ? `Docente (${currentUser.name})` : 'Invitado (Solo Lectura)'}
          </span>
        </div>
      </div>

      {/* Catalog Spaces Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {displayedSpaces.map((space) => {
          const isClassroom = space.type === 'aula';

          return (
            <div
              key={space.id}
              className={`bg-slate-950 border rounded-2xl p-5 flex flex-col justify-between transition-all shadow-xl relative overflow-hidden ${
                isClassroom && space.isOccupied
                  ? 'border-amber-500/50 bg-slate-950/95'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                    isClassroom
                      ? 'bg-sky-950 text-sky-300 border-sky-800'
                      : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                  }`}>
                    {isClassroom ? 'Aula Académica' : 'Área Verde Campus'}
                  </span>

                  {isClassroom ? (
                    <span className={`text-xs font-extrabold px-2.5 py-0.5 rounded-full border flex items-center gap-1.5 ${
                      space.isOccupied
                        ? 'bg-amber-950 text-amber-300 border-amber-800 animate-pulse'
                        : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    }`}>
                      {space.isOccupied ? (
                        <>
                          <Lock className="w-3.5 h-3.5 text-amber-400" />
                          OCUPADA
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                          DESOCUPADA
                        </>
                      )}
                    </span>
                  ) : (
                    <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/40 border border-emerald-900/60 px-2 py-0.5 rounded-full">
                      No es Aula (No Ocupable)
                    </span>
                  )}
                </div>

                {/* Name & Block */}
                <div className="flex items-start gap-3">
                  <div className={`p-2.5 rounded-xl border shrink-0 ${
                    isClassroom ? 'bg-blue-900/40 border-blue-800 text-sky-400' : 'bg-emerald-900/40 border-emerald-800 text-emerald-400'
                  }`}>
                    {isClassroom ? <Building2 className="w-6 h-6" /> : <Trees className="w-6 h-6" />}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-100 text-base leading-tight">
                      {space.name}
                    </h3>
                    <p className="text-xs text-sky-400 font-medium mt-0.5">
                      {space.block} {space.floor ? `• ${space.floor}` : ''}
                    </p>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-400 mt-3 leading-relaxed">
                  {space.description}
                </p>

                {/* Teacher Owner info if occupied */}
                {isClassroom && space.isOccupied && space.occupiedBy && (
                  <div className="mt-3 p-2.5 bg-amber-950/40 border border-amber-800/60 rounded-xl text-xs text-amber-200 space-y-1">
                    <div className="flex items-center gap-1.5 font-semibold text-amber-300">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      Ocupada por Docente:
                    </div>
                    <div className="font-mono text-[11px] truncate text-amber-100">
                      {space.occupiedBy}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Button Section */}
              <div className="mt-5 pt-3 border-t border-slate-900 flex flex-col gap-2">
                {isClassroom ? (
                  isTeacher ? (
                    <button
                      onClick={() => handleInitiateScan(space)}
                      className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                        space.isOccupied
                          ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-950/50'
                          : 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-950/50'
                      }`}
                    >
                      <Camera className="w-4 h-4" />
                      {space.isOccupied ? 'Desmarcar (Escanear QR por Cámara)' : 'Ocupar Aula (Escanear QR por Cámara)'}
                    </button>
                  ) : (
                    <div className={`w-full py-2.5 px-3.5 rounded-xl border text-xs font-bold flex items-center justify-between ${
                      space.isOccupied
                        ? 'bg-amber-950/40 border-amber-800/60 text-amber-300'
                        : 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                    }`}>
                      <div className="flex items-center gap-2">
                        {space.isOccupied ? (
                          <Lock className="w-4 h-4 text-amber-400" />
                        ) : (
                          <Unlock className="w-4 h-4 text-emerald-400" />
                        )}
                        <span>
                          {space.isOccupied ? 'Estado: Aula Ocupada' : 'Estado: Aula Desocupada'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono font-normal">
                        Solo Lectura
                      </span>
                    </div>
                  )
                ) : (
                  <button
                    onClick={() => handleInitiateScan(space)}
                    className="w-full py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-500 text-xs font-medium cursor-not-allowed flex items-center justify-center gap-1.5"
                  >
                    <Info className="w-3.5 h-3.5" />
                    Espacio no ocupable por reglamentación
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* QR Code Scanner Camera Modal */}
      {selectedSpaceForScan && (
        <QrScannerModal
          targetSpace={selectedSpaceForScan}
          currentUser={currentUser}
          isOpen={isScannerOpen}
          onClose={() => {
            setIsScannerOpen(false);
            setSelectedSpaceForScan(null);
          }}
          onScanSuccess={handleScanSuccess}
        />
      )}

      {/* Separate QR Exporter Modal */}
      <QrExporterModal
        spaces={spaces}
        isOpen={isExporterOpen}
        onClose={() => setIsExporterOpen(false)}
      />
    </div>
  );
};
