import React from 'react';

interface UtmachLogoProps {
  className?: string;
  showText?: boolean;
}

export const UtmachLogo: React.FC<UtmachLogoProps> = ({ className = 'w-10 h-10', showText = true }) => {
  return (
    <div className="flex items-center gap-3">
      <div className={`relative flex items-center justify-center rounded-xl bg-gradient-to-br from-blue-900 via-blue-800 to-indigo-950 p-2 shadow-lg shadow-blue-950/50 border border-blue-500/30 ${className}`}>
        {/* SVG Icon simulating UTMACH institutional shield & torch */}
        <svg viewBox="0 0 100 100" className="w-full h-full text-blue-400" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Base Shield */}
          <path d="M50 8L88 22V52C88 74 50 92 50 92C50 92 12 74 12 52V22L50 8Z" fill="#002855" stroke="#0077FE" strokeWidth="3.5" />
          {/* Inner Accent */}
          <path d="M50 15L80 26V50C80 68 50 82 50 82C50 82 20 68 20 50V26L50 15Z" fill="#001838" />
          {/* Torch / Sun Rays (Gold) */}
          <circle cx="50" cy="38" r="12" fill="#EAAA00" />
          <path d="M50 20V26M50 50V56M32 38H38M62 38H68M37 25L42 30M63 25L58 30M37 51L42 46M63 51L58 46" stroke="#EAAA00" strokeWidth="3" strokeLinecap="round" />
          {/* Open Book */}
          <path d="M28 62C38 60 48 64 50 67C52 64 62 60 72 62V78C62 76 52 80 50 82C48 80 38 76 28 78V62Z" fill="#FFFFFF" stroke="#0056B3" strokeWidth="2" />
          <path d="M50 67V82" stroke="#0056B3" strokeWidth="2" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-lg tracking-wider text-white bg-gradient-to-r from-blue-300 via-sky-200 to-amber-300 bg-clip-text text-transparent">
              UTMACH
            </span>
            <span className="bg-blue-600 text-blue-100 text-[10px] font-black px-1.5 py-0.5 rounded tracking-widest uppercase">
              HUB
            </span>
          </div>
          <span className="text-[10px] font-medium text-slate-400 tracking-tight leading-none uppercase">
            Universidad Técnica de Machala
          </span>
        </div>
      )}
    </div>
  );
};
