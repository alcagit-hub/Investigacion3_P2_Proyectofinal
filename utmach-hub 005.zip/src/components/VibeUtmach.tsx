import React, { useState } from 'react';
import { VibeMessage, UserAccount } from '../types';
import { MessageSquare, Send, Sparkles, User, ShieldCheck, UserCheck, Trash2, Bell } from 'lucide-react';

interface VibeUtmachProps {
  messages: VibeMessage[];
  currentUser: UserAccount | null;
  onSendMessage: (content: string) => void;
  secondsLeft: number;
}

export const VibeUtmach: React.FC<VibeUtmachProps> = ({
  messages,
  currentUser,
  onSendMessage,
  secondsLeft,
}) => {
  const [inputText, setInputText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-900/60 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-gradient-to-r from-sky-500 to-indigo-500 text-white text-[10px] font-black px-2 py-0.5 rounded tracking-widest uppercase shadow">
                RED SOCIAL
              </span>
              <span className="text-xs text-sky-300 font-medium">Comunidad Universitaria</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
              Vibe UTMACH Feed Global
            </h2>
            <p className="text-xs text-slate-300 max-w-xl mt-1 leading-relaxed">
              Módulo de mensajería pública en vivo para Docentes e Invitados. Los mensajes emitidos notifican en pantalla a la comunidad y son reiniciados automáticamente cada 60 segundos por el temporizador maestro.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl flex items-center gap-3 shrink-0">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Limpieza automática en:</span>
              <span className="font-mono text-sky-400 font-extrabold text-base">
                00:{secondsLeft < 10 ? '0' : ''}{secondsLeft}s
              </span>
            </div>
            <Trash2 className="w-5 h-5 text-rose-400 animate-pulse" />
          </div>
        </div>
      </div>

      {/* Main Feed Container */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
        {/* Message Input Box */}
        <form onSubmit={handleSubmit} className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              {currentUser?.role === 'teacher' ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              ) : (
                <UserCheck className="w-4 h-4 text-sky-400" />
              )}
              Publicando como: <strong className="text-slate-100">{currentUser?.name || 'Invitado UTMACH'}</strong>
            </span>
            <span className="text-[11px] text-sky-400 font-mono">Emite notificación global</span>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Escribe un aviso, saludo o comentario para el campus UTMACH..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
            <button
              type="submit"
              className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-sky-950/50 shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              Publicar
            </button>
          </div>
        </form>

        {/* Message Stream */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <Bell className="w-4 h-4 text-sky-400" />
            Mensajes Recientes ({messages.length})
          </h3>

          <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className="bg-slate-950 border border-slate-800/90 rounded-xl p-4 flex flex-col gap-2 hover:border-slate-700 transition-all shadow-sm"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`p-1 rounded-lg ${
                      msg.authorRole === 'teacher' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-sky-950 text-sky-400 border border-sky-800'
                    }`}>
                      <User className="w-3.5 h-3.5" />
                    </span>
                    <span className="font-bold text-slate-200">{msg.author}</span>
                    <span className={`text-[10px] px-2 py-0.2 rounded font-semibold ${
                      msg.authorRole === 'teacher' ? 'bg-emerald-900/60 text-emerald-300' : 'bg-sky-900/60 text-sky-300'
                    }`}>
                      {msg.authorRole === 'teacher' ? 'Docente' : 'Invitado'}
                    </span>
                  </div>

                  <span className="text-[10px] text-slate-500 font-mono">
                    {msg.timestamp}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed pl-7">
                  {msg.content}
                </p>
              </div>
            ))}

            {messages.length === 0 && (
              <div className="text-center py-12 text-slate-500 text-xs bg-slate-950 rounded-xl border border-slate-800/80">
                <MessageSquare className="w-8 h-8 text-slate-600 mx-auto mb-2 opacity-50" />
                No hay mensajes activos en el feed Vibe UTMACH.
                <br />
                <span className="text-[11px] text-slate-600 mt-1 block">
                  Sé el primero en enviar un saludo o aviso a la comunidad.
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
