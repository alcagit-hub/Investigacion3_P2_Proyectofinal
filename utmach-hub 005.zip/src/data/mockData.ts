import { UserAccount, CampusSpace } from '../types';

export const INSTITUTIONAL_PASSWORD = 'UTMACH2026';

export const DEFAULT_TEACHERS: UserAccount[] = [
  {
    id: 'doc-1',
    email: 'docente.sistemas@utmachala.edu.ec',
    name: 'Ing. Carlos Mendoza',
    role: 'teacher',
    isDefault: true,
  },
  {
    id: 'doc-2',
    email: 'docente.agronomia@utmachala.edu.ec',
    name: 'Dra. María Elena Prado',
    role: 'teacher',
    isDefault: true,
  },
  {
    id: 'doc-3',
    email: 'docente.medicina@utmachala.edu.ec',
    name: 'Dr. Roberto Silva',
    role: 'teacher',
    isDefault: true,
  }
];

export const INITIAL_SPACES: CampusSpace[] = [
  // --- AULAS ---
  {
    id: 'aula-101',
    name: 'Aula 101 - FICI',
    type: 'aula',
    block: 'Bloque A - Facultad de Ingeniería',
    capacity: 40,
    qrToken: 'UTMACH-AULA-101',
    isOccupied: false,
    occupiedBy: null,
    description: 'Aula climatizada con proyector HD y sistema de sonido para Ingeniería Civil e Informática.',
    x: 25,
    y: 35,
    floor: 'Planta Baja'
  },
  {
    id: 'aula-102',
    name: 'Aula 102 - FICI',
    type: 'aula',
    block: 'Bloque A - Facultad de Ingeniería',
    capacity: 45,
    qrToken: 'UTMACH-AULA-102',
    isOccupied: false,
    occupiedBy: null,
    description: 'Aula magna interactiva con pantalla inteligente y conexiones de red de alta velocidad.',
    x: 35,
    y: 35,
    floor: 'Planta Baja'
  },
  {
    id: 'aula-201',
    name: 'Aula 201 - Empresariales',
    type: 'aula',
    block: 'Bloque B - Ciencias Empresariales',
    capacity: 35,
    qrToken: 'UTMACH-AULA-201',
    isOccupied: false,
    occupiedBy: null,
    description: 'Espacio para clases teóricas de Contabilidad, Administración y Economía.',
    x: 65,
    y: 35,
    floor: 'Piso 2'
  },
  {
    id: 'aula-202',
    name: 'Aula 202 - Salud',
    type: 'aula',
    block: 'Bloque C - Ciencias Químicas y Salud',
    capacity: 30,
    qrToken: 'UTMACH-AULA-202',
    isOccupied: false,
    occupiedBy: null,
    description: 'Aula equipada con modelos anatómicos 3D y mesas de estudio colaborativo.',
    x: 75,
    y: 50,
    floor: 'Piso 2'
  },
  {
    id: 'lab-sistemas-1',
    name: 'Laboratorio de Sistemas 1',
    type: 'aula',
    block: 'Bloque A - FICI',
    capacity: 30,
    qrToken: 'UTMACH-LAB-SISTEMAS-1',
    isOccupied: false,
    occupiedBy: null,
    description: 'Laboratorio de desarrollo de software con 30 equipos i7, GPUs de rendimiento y fibra óptica.',
    x: 30,
    y: 25,
    floor: 'Piso 1'
  },

  // --- ÁREAS VERDES ---
  {
    id: 'area-jardin-central',
    name: 'Jardín Central UTMACH',
    type: 'area_verde',
    block: 'Zona Central Campus',
    description: 'Amplia área verde con pérgolas, árboles nativos machaleños y zonas de descanso para estudiantes.',
    x: 50,
    y: 50,
    isOccupied: false,
    occupiedBy: null
  },
  {
    id: 'area-bosquetillo',
    name: 'Bosquetillo Agropecuario',
    type: 'area_verde',
    block: 'Zona Norte - Ciencias Agropecuarias',
    description: 'Reserva ecológica y vivero universitario con senderos y biodiversidad local.',
    x: 45,
    y: 20,
    isOccupied: false,
    occupiedBy: null
  },

  // --- BAR ---
  {
    id: 'bar-central',
    name: 'Bar Universitario - Cafetería Central',
    type: 'bar',
    block: 'Plaza Estudiantil',
    description: 'Cafetería y comedor universitario con opciones de menú saludable, bebidas e hidratación.',
    x: 55,
    y: 65,
    isOccupied: false,
    occupiedBy: null
  },

  // --- BAÑOS ---
  {
    id: 'bano-bloque-a',
    name: 'Servicios Higiénicos - Bloque A',
    type: 'bano',
    block: 'Bloque A',
    description: 'Batería sanitaria accesible para damas, caballeros y personas con movilidad reducida.',
    x: 20,
    y: 40,
    isOccupied: false,
    occupiedBy: null
  },
  {
    id: 'bano-bloque-b',
    name: 'Servicios Higiénicos - Bloque B',
    type: 'bano',
    block: 'Bloque B',
    description: 'Batería sanitaria accesible del edificio de Ciencias Empresariales.',
    x: 70,
    y: 40,
    isOccupied: false,
    occupiedBy: null
  },

  // --- ENTRADA PRINCIPAL ---
  {
    id: 'entrada-principal',
    name: 'Entrada Principal (Arco Panamericana)',
    type: 'entrada_principal',
    block: 'Acceso Sur',
    description: 'Portó monumental de ingreso vehicular y peatonal con garita de control e identificación.',
    x: 50,
    y: 90,
    isOccupied: false,
    occupiedBy: null
  },

  // --- ENTRADA TRASERA ---
  {
    id: 'entrada-trasera',
    name: 'Entrada Trasera (Acceso Posterior)',
    type: 'entrada_trasera',
    block: 'Acceso Norte',
    description: 'Ingreso secundario con arco de seguridad orientado a las facultades del sector norte.',
    x: 50,
    y: 10,
    isOccupied: false,
    occupiedBy: null
  }
];
