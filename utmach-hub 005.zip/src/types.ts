export type UserRole = 'guest' | 'teacher';

export interface UserAccount {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  isDefault?: boolean;
}

export type SpaceType = 
  | 'aula' 
  | 'area_verde' 
  | 'bar' 
  | 'bano' 
  | 'entrada_principal' 
  | 'entrada_trasera';

export interface CampusSpace {
  id: string;
  name: string;
  type: SpaceType;
  block: string;
  capacity?: number;
  qrToken?: string; // Tokens de QR únicos para aulas
  isOccupied: boolean;
  occupiedBy: string | null; // Correo del docente que ocupó el aula
  occupiedByName?: string | null;
  occupiedAt?: string | null;
  description: string;
  x: number; // Coordenada X relativa no mapa (0-100)
  y: number; // Coordenada Y relativa no mapa (0-100)
  floor?: string;
}

export interface IncidentReport {
  id: string;
  locationId: string;
  locationName: string;
  description: string;
  reportedBy: string;
  reportedAt: string;
  confirms: number;
  denials: number;
  votedUsers: string[];
}

export interface VibeMessage {
  id: string;
  author: string;
  authorRole: UserRole;
  content: string;
  timestamp: string;
}

export type ActiveModule = 
  | 'panel_principal' 
  | 'gestion_espacios' 
  | 'hub_destinos' 
  | 'vibe_utmach' 
  | 'qr_export';

export interface ToastNotification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
}

export interface UserSessionStats {
  totalMeters: number;
  visitedPlaces: { [spaceId: string]: number };
}

